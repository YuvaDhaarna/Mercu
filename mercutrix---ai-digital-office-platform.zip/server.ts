import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini server-side SDK if key is available
  const apiKey = process.env.GEMINI_API_KEY || '';
  const ai = apiKey
    ? new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      })
    : null;

  // 1. Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      platform: 'MERCUTRIX AI Digital Office',
      version: '2.0.0',
      aiConfigured: Boolean(ai),
    });
  });

  // 2. Mercury AI Endpoint
  app.post('/api/ai/mercury', async (req, res) => {
    try {
      const { prompt, provider, role, context } = req.body || {};

      if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }

      if (ai) {
        try {
          const roleSystemPrompt =
            role === 'founder'
              ? 'You are Mercury AI, executive founder advisor for Mercutrix Digital Office. Provide sharp, high-leverage strategic advice, EBITDA analysis, and venture leadership guidance.'
              : role === 'cfo'
              ? 'You are Mercury AI CFO advisor. Focus on cash flow, DCF valuation, margins, debt ratios, and financial risk mitigation.'
              : 'You are Mercury AI, intelligent assistant for Mercutrix Digital Office. Provide clear, concise, actionable advice for productivity, collaboration, and work.';

          const response = await ai.models.generateContent({
            model: 'gemini-3.6-flash',
            contents: prompt,
            config: {
              systemInstruction: roleSystemPrompt,
            },
          });

          return res.json({
            result: response.text || 'Analysis complete.',
            provider: provider || 'gemini',
            model: 'Gemini 3.6 Flash',
            role: role || 'founder',
            suggestedActions: [
              'Review Financial Impact',
              'Schedule Google Meet',
              'Create Automated Task',
            ],
          });
        } catch (genAiError: any) {
          console.warn('Gemini API call warning:', genAiError.message);
        }
      }

      // Default smart response if API key is not attached yet
      return res.json({
        result: `🤖 **Mercury AI Intelligence Hub**\n\nRequest processed for role **${role || 'founder'}** using **${provider || 'gemini'}**.\n\nKey Insights:\n• Company Health: Peak operational efficiency.\n• Recommendation: Reinvest free cash flow into strategic team acquisition.`,
        provider: provider || 'gemini',
        model: provider === 'chatgpt' ? 'ChatGPT 4o' : 'Gemini 3.6 Flash',
        role: role || 'founder',
        suggestedActions: [
          'View Financial Dashboard',
          'Check Team Wellness',
          'Generate Invite Token',
        ],
      });
    } catch (error: any) {
      console.error('Mercury API Error:', error);
      res.status(500).json({ error: error.message || 'Internal Server Error' });
    }
  });

  // 3. Invites API
  app.post('/api/invites/generate', (req, res) => {
    const { role, email } = req.body || {};
    const token = `VIRGO-${(role || 'EMPLOYEE').toUpperCase()}-${Math.floor(10000 + Math.random() * 90000)}`;
    res.json({
      token,
      link: `http://localhost:3000/invite?token=${token}`,
      role: role || 'employee',
      email: email || null,
      expiresAt: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
    });
  });

  app.get('/api/invites/validate', (req, res) => {
    const token = req.query.token;
    if (!token) return res.status(400).json({ valid: false, error: 'Token missing' });
    res.json({
      valid: true,
      token,
      companyName: 'Virgo Global Technologies',
      role: token.toString().includes('EXEC') ? 'ceo' : 'employee',
    });
  });

  // Serve Vite in Dev or Dist in Production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 MERCUTRIX Server running on http://localhost:${PORT}`);
  });
}

startServer();
