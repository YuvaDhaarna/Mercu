import { Role } from '../types';

export const ALL_ROLES: Role[] = [
  'founder',
  'ceo',
  'cfo',
  'coo',
  'cto',
  'cmo',
  'chro',
  'cio',
  'chairman',
  'vice_chairman',
  'president',
  'vice_president',
  'managing_director',
  'hr',
  'manager',
  'team_leader',
  'supervisor',
  'employee',
  'intern',
  'guest',
];

export const ROLE_DISPLAY_NAMES: Record<Role, string> = {
  founder: 'Founder',
  ceo: 'Chief Executive Officer (CEO)',
  cfo: 'Chief Financial Officer (CFO)',
  coo: 'Chief Operating Officer (COO)',
  cto: 'Chief Technology Officer (CTO)',
  cmo: 'Chief Marketing Officer (CMO)',
  chro: 'Chief Human Resources Officer (CHRO)',
  cio: 'Chief Information Officer (CIO)',
  chairman: 'Chairman of the Board',
  vice_chairman: 'Vice Chairman',
  president: 'President',
  vice_president: 'Vice President',
  managing_director: 'Managing Director',
  hr: 'HR Manager',
  manager: 'Department Manager',
  team_leader: 'Team Lead',
  supervisor: 'Supervisor',
  employee: 'Employee',
  intern: 'Intern',
  guest: 'Guest',
};

export const TIER_MAP: Record<Role, 'FOUNDER' | 'KEY' | 'DELTA' | 'ALPHA'> = {
  founder: 'FOUNDER',
  ceo: 'KEY',
  cfo: 'KEY',
  coo: 'KEY',
  cto: 'KEY',
  cmo: 'KEY',
  chro: 'KEY',
  cio: 'KEY',
  chairman: 'KEY',
  vice_chairman: 'KEY',
  president: 'KEY',
  vice_president: 'KEY',
  managing_director: 'KEY',
  hr: 'DELTA',
  manager: 'DELTA',
  team_leader: 'DELTA',
  supervisor: 'DELTA',
  employee: 'ALPHA',
  intern: 'ALPHA',
  guest: 'ALPHA',
};

export function getTier(role: Role): string {
  return TIER_MAP[role] || 'ALPHA';
}

export function isFounder(role: Role): boolean {
  return role === 'founder';
}

export function isCSuite(role: Role): boolean {
  return ['ceo', 'cfo', 'coo', 'cto', 'cmo', 'chro', 'cio'].includes(role);
}

export function isExecutive(role: Role): boolean {
  return (
    isFounder(role) ||
    isCSuite(role) ||
    ['chairman', 'vice_chairman', 'president', 'vice_president', 'managing_director'].includes(role)
  );
}

export function isManager(role: Role): boolean {
  return isExecutive(role) || ['hr', 'manager', 'team_leader', 'supervisor'].includes(role);
}

export function isHR(role: Role): boolean {
  return role === 'hr' || role === 'chro' || isFounder(role);
}

export function getDefaultRoute(role: Role): string {
  if (isFounder(role)) return 'founder-room';
  if (isExecutive(role)) return 'executive-suite';
  if (isManager(role)) return 'manager-hub';
  return 'employee-workspace';
}

export const MODULE_PERMISSIONS: Record<string, Role[]> = {
  'founder-room': ['founder'],
  'executive-suite': [
    'founder',
    'ceo',
    'cfo',
    'coo',
    'cto',
    'cmo',
    'chro',
    'cio',
    'chairman',
    'vice_chairman',
    'president',
    'vice_president',
    'managing_director',
  ],
  'financial-intelligence': [
    'founder',
    'ceo',
    'cfo',
    'president',
    'chairman',
    'managing_director',
    'coo',
  ],
  'manager-hub': [
    'founder',
    'ceo',
    'cfo',
    'coo',
    'cto',
    'cmo',
    'chro',
    'cio',
    'chairman',
    'president',
    'hr',
    'manager',
    'team_leader',
    'supervisor',
  ],
  'employee-management': [
    'founder',
    'ceo',
    'cfo',
    'coo',
    'cto',
    'cmo',
    'chro',
    'cio',
    'chairman',
    'president',
    'hr',
    'manager',
  ],
  'invite-generator': ['founder', 'hr', 'ceo', 'president'],
  'audit-security': ['founder', 'cio', 'cto', 'hr'],
  'database-schema': ['founder', 'cto', 'cio', 'ceo'],
  'employee-workspace': ALL_ROLES,
  'office-rooms': ALL_ROLES,
  'wellness-productivity': ALL_ROLES,
  'company-feed': ALL_ROLES,
  'google-workspace': ALL_ROLES,
  'no-code-automation': ALL_ROLES,
  'knowledge-wiki': ALL_ROLES,
  'mercury-ai': ALL_ROLES,
};

export function canAccess(role: Role, moduleId: string): boolean {
  const allowed = MODULE_PERMISSIONS[moduleId];
  if (!allowed) return true;
  return allowed.includes(role);
}
