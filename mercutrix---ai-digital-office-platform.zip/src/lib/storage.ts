import {
  AuditLog,
  ChatMessage,
  Company,
  FeedPost,
  FinancialMetricRecord,
  HealthMetrics,
  InviteToken,
  OfficeRoom,
  Profile,
  Role,
  SecurityAlert,
  TaskItem,
  WorkflowRule,
} from '../types';

const INITIAL_COMPANY: Company = {
  id: 'comp-virgo-1',
  name: 'Virgo Global Technologies',
  slug: 'virgo-global',
  createdBy: 'user-founder-1',
  createdAt: '2026-01-01T00:00:00Z',
};

const INITIAL_PROFILES: Profile[] = [
  {
    id: 'user-founder-1',
    fullName: 'Aria Thorne (Founder)',
    email: 'aria.thorne@virgotech.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
    role: 'founder',
    companyId: 'comp-virgo-1',
    employeeId: 'EMP-000001',
    jobTitle: 'Founder & Chief Architect',
    departmentName: 'Executive',
    skills: ['AI Systems', 'Venture Strategy', 'Capital Allocation', 'System Architecture'],
    isBanned: false,
    isActive: true,
    status: 'active',
    lastLogin: new Date().toISOString(),
  },
  {
    id: 'user-ceo-1',
    fullName: 'Julian Vance (CEO)',
    email: 'julian.vance@virgotech.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
    role: 'ceo',
    companyId: 'comp-virgo-1',
    employeeId: 'EMP-000002',
    jobTitle: 'Chief Executive Officer',
    departmentName: 'Executive',
    skills: ['Global Scaling', 'Investor Relations', 'Operations', 'Leadership'],
    isBanned: false,
    isActive: true,
    status: 'active',
    lastLogin: new Date().toISOString(),
  },
  {
    id: 'user-cfo-1',
    fullName: 'Elena Rostova (CFO)',
    email: 'elena.rostova@virgotech.io',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250',
    role: 'cfo',
    companyId: 'comp-virgo-1',
    employeeId: 'EMP-000003',
    jobTitle: 'Chief Financial Officer',
    departmentName: 'Finance',
    skills: ['Financial Modeling', 'DCF Valuation', 'EBITDA Optimization', 'Risk Control'],
    isBanned: false,
    isActive: true,
    status: 'active',
    lastLogin: new Date().toISOString(),
  },
  {
    id: 'user-cto-1',
    fullName: 'Marcus Sterling (CTO)',
    email: 'marcus.sterling@virgotech.io',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=250',
    role: 'cto',
    companyId: 'comp-virgo-1',
    employeeId: 'EMP-000004',
    jobTitle: 'Chief Technology Officer',
    departmentName: 'Engineering',
    skills: ['Cloud Architecture', 'Distributed Systems', 'Security', 'DevOps'],
    isBanned: false,
    isActive: true,
    status: 'active',
    lastLogin: new Date().toISOString(),
  },
  {
    id: 'user-hr-1',
    fullName: 'Sophia Martinez (HR)',
    email: 'sophia.m@virgotech.io',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=250',
    role: 'hr',
    companyId: 'comp-virgo-1',
    employeeId: 'EMP-000005',
    jobTitle: 'VP of Human Resources',
    departmentName: 'People & Culture',
    skills: ['Talent Acquisition', 'Role Hierarchy', 'Culture', 'Compliance'],
    isBanned: false,
    isActive: true,
    status: 'active',
    lastLogin: new Date().toISOString(),
  },
  {
    id: 'user-eng-1',
    fullName: 'David Chen (Senior Engineer)',
    email: 'david.chen@virgotech.io',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=250',
    role: 'employee',
    companyId: 'comp-virgo-1',
    employeeId: 'EMP-000102',
    jobTitle: 'Staff Full Stack Developer',
    departmentName: 'Engineering',
    skills: ['TypeScript', 'Next.js', 'PostgreSQL', 'GraphQL'],
    isBanned: false,
    isActive: true,
    status: 'active',
    lastLogin: new Date().toISOString(),
  },
];

const INITIAL_ROOMS: OfficeRoom[] = [
  {
    id: 'room-founder-1',
    companyId: 'comp-virgo-1',
    name: 'Founder Sanctum & Command Room',
    slug: 'founder-sanctum',
    roomType: 'founder',
    createdBy: 'user-founder-1',
    memberCount: 2,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'room-exec-1',
    companyId: 'comp-virgo-1',
    name: 'Executive Boardroom',
    slug: 'exec-boardroom',
    roomType: 'office',
    createdBy: 'user-ceo-1',
    memberCount: 6,
    createdAt: '2026-01-02T00:00:00Z',
  },
  {
    id: 'room-eng-1',
    companyId: 'comp-virgo-1',
    name: 'Engineering & Core Tech Hub',
    slug: 'engineering-hub',
    roomType: 'office',
    createdBy: 'user-cto-1',
    memberCount: 14,
    createdAt: '2026-01-03T00:00:00Z',
  },
  {
    id: 'room-growth-1',
    companyId: 'comp-virgo-1',
    name: 'Growth & Global Sales Room',
    slug: 'growth-sales',
    roomType: 'office',
    createdBy: 'user-ceo-1',
    memberCount: 9,
    createdAt: '2026-01-04T00:00:00Z',
  },
];

const INITIAL_TASKS: TaskItem[] = [
  {
    id: 'task-1',
    roomId: 'room-founder-1',
    title: 'Review Q3 Financial Projections & DCF Valuation Model',
    description: 'Analyze revenue multi-scenario, EBITDA trajectory, and debt-to-equity targets with Elena.',
    assignedTo: 'user-cfo-1',
    assignedToName: 'Elena Rostova (CFO)',
    createdBy: 'user-founder-1',
    status: 'in_progress',
    priority: 'critical',
    dueDate: '2026-07-28',
    createdAt: '2026-07-20T10:00:00Z',
  },
  {
    id: 'task-2',
    roomId: 'room-eng-1',
    title: 'Deploy Mercury AI Multi-Model Orchestrator Engine',
    description: 'Ensure sub-second failover between Gemini 3.6 Flash, ChatGPT 4o, and DeepSeek for optimal latency.',
    assignedTo: 'user-eng-1',
    assignedToName: 'David Chen (Senior Engineer)',
    createdBy: 'user-cto-1',
    status: 'in_progress',
    priority: 'high',
    dueDate: '2026-07-26',
    createdAt: '2026-07-21T09:30:00Z',
  },
  {
    id: 'task-3',
    roomId: 'room-exec-1',
    title: 'Finalize Founder Invite Tokens & Security Audit Log Rules',
    description: 'Verify RLS rules across all 25 Supabase tables for Founder, Executive, and Manager roles.',
    assignedTo: 'user-hr-1',
    assignedToName: 'Sophia Martinez (HR)',
    createdBy: 'user-founder-1',
    status: 'done',
    priority: 'high',
    dueDate: '2026-07-23',
    createdAt: '2026-07-18T14:00:00Z',
  },
  {
    id: 'task-4',
    roomId: 'room-growth-1',
    title: 'Launch Global Corporate Wellness & Focus Score Campaign',
    description: 'Integrate team step challenges and deep work Pomodoro tracking across all departments.',
    assignedTo: 'user-ceo-1',
    assignedToName: 'Julian Vance (CEO)',
    createdBy: 'user-founder-1',
    status: 'pending',
    priority: 'medium',
    dueDate: '2026-08-01',
    createdAt: '2026-07-22T11:00:00Z',
  },
];

const INITIAL_HEALTH: HealthMetrics = {
  id: 'health-founder-1',
  userId: 'user-founder-1',
  recordedDate: new Date().toISOString().split('T')[0],
  steps: 10420,
  caloriesBurned: 580,
  activeMinutes: 45,
  sleepHours: 7.8,
  heartRateAvg: 68,
  stressLevel: 3,
  moodScore: 9,
  energyLevel: 8,
  focusScore: 92,
  screenTimeMinutes: 210,
  deepWorkMinutes: 180,
  breakTaken: 4,
};

const INITIAL_FINANCIALS: FinancialMetricRecord[] = [
  {
    id: 'fin-q1-2026',
    period: '2026 Q1',
    revenue: 4200000,
    cogs: 840000,
    operatingExpenses: 1950000,
    operatingIncome: 1410000,
    interestExpense: 65000,
    netIncome: 1120000,
    totalAssets: 18500000,
    totalLiabilities: 4200000,
    totalEquity: 14300000,
    operatingCashFlow: 1580000,
    freeCashFlow: 1250000,
    employees: 48,
  },
  {
    id: 'fin-q2-2026',
    period: '2026 Q2',
    revenue: 5800000,
    cogs: 1100000,
    operatingExpenses: 2400000,
    operatingIncome: 2300000,
    interestExpense: 60000,
    netIncome: 1840000,
    totalAssets: 22400000,
    totalLiabilities: 4800000,
    totalEquity: 17600000,
    operatingCashFlow: 2100000,
    freeCashFlow: 1720000,
    employees: 62,
  },
];

const INITIAL_FEED: FeedPost[] = [
  {
    id: 'post-1',
    authorId: 'user-founder-1',
    authorName: 'Aria Thorne (Founder)',
    authorRole: 'founder',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
    content: '🚀 MERCUTRIX AI Digital Office v2.0 is officially live across all regional workspaces! Welcome to effortless digital productivity, AI intelligence, and real-time collaboration.',
    type: 'announcement',
    likes: 24,
    likedByMe: true,
    comments: [
      {
        id: 'c-1',
        postId: 'post-1',
        authorId: 'user-ceo-1',
        authorName: 'Julian Vance (CEO)',
        content: 'Remarkable accomplishment team! The Mercury AI orchestrator is already saving executive leadership 3+ hours daily.',
        createdAt: '2026-07-23T18:00:00Z',
      },
    ],
    createdAt: '2026-07-23T17:30:00Z',
  },
  {
    id: 'post-2',
    authorId: 'user-cfo-1',
    authorName: 'Elena Rostova (CFO)',
    authorRole: 'cfo',
    authorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250',
    content: '📈 Q2 Financial Intelligence Report: Operating EBITDA margin reached 39.6% with an Altman Z-score of 3.84 (Safe zone). Capital allocation projections updated in Mercury AI.',
    type: 'achievement',
    likes: 18,
    comments: [],
    createdAt: '2026-07-22T14:15:00Z',
  },
];

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    roomId: 'room-founder-1',
    userId: 'user-founder-1',
    userName: 'Aria Thorne',
    userRole: 'founder',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
    content: 'Mercury AI: Run a comparative analysis of our debt-to-equity ratio vs industry benchmarks.',
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'msg-2',
    roomId: 'room-founder-1',
    userId: 'user-cfo-1',
    userName: 'Elena Rostova',
    userRole: 'cfo',
    userAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250',
    content: 'Our debt-to-equity stands at 0.27, well below the conservative threshold of 0.8. We have strong cash flow reserves.',
    createdAt: new Date(Date.now() - 3000000).toISOString(),
  },
];

const INITIAL_INVITES: InviteToken[] = [
  {
    id: 'inv-1',
    token: 'VIRGO-EXEC-99218',
    companyId: 'comp-virgo-1',
    role: 'ceo',
    createdBy: 'user-founder-1',
    expiresAt: '2026-08-01T00:00:00Z',
    createdAt: '2026-07-20T00:00:00Z',
  },
  {
    id: 'inv-2',
    token: 'VIRGO-ENG-10822',
    companyId: 'comp-virgo-1',
    role: 'employee',
    createdBy: 'user-founder-1',
    expiresAt: '2026-08-01T00:00:00Z',
    createdAt: '2026-07-21T00:00:00Z',
  },
];

const INITIAL_AUDITS: AuditLog[] = [
  {
    id: 'audit-1',
    userId: 'user-founder-1',
    userName: 'Aria Thorne',
    action: 'GENERATE_INVITE_TOKEN',
    targetType: 'INVITE_TOKEN',
    details: 'Generated Founder token for Executive onboarding',
    ipAddress: '192.168.1.104',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
  },
  {
    id: 'audit-2',
    userId: 'user-cfo-1',
    userName: 'Elena Rostova',
    action: 'UPDATE_FINANCIAL_METRICS',
    targetType: 'FINANCIAL_RECORD',
    details: 'Updated Q2 2026 EBITDA and DCF valuation baseline',
    ipAddress: '192.168.1.112',
    timestamp: new Date(Date.now() - 14400000).toISOString(),
  },
];

const INITIAL_WORKFLOWS: WorkflowRule[] = [
  {
    id: 'wf-1',
    name: 'Auto-Notify Manager on Stress Score > 7',
    triggerType: 'health_alert',
    actionType: 'notify_manager',
    trigger: 'High Stress Score (>7/10)',
    action: 'Auto-reschedule meetings & notify manager',
    active: true,
    config: { threshold: 7, action: 'Send restorative break recommendation' },
    status: 'active',
    lastRun: new Date().toISOString(),
  },
  {
    id: 'wf-2',
    name: 'Q3 Task Auto-Assign & Calendar Block',
    triggerType: 'task_status',
    actionType: 'create_task',
    trigger: 'Overdue Critical Task Count > 3',
    action: 'Escalate priority & assign Mercury AI helper',
    active: true,
    config: { roleTarget: 'employee', autoCalendar: true },
    status: 'active',
    lastRun: new Date().toISOString(),
  },
];

// Local store state
class LocalStore {
  private currentRole: Role = 'founder';
  private currentUserId: string = 'user-founder-1';
  private company: Company = INITIAL_COMPANY;
  private profiles: Profile[] = INITIAL_PROFILES;
  private rooms: OfficeRoom[] = INITIAL_ROOMS;
  private tasks: TaskItem[] = INITIAL_TASKS;
  private health: HealthMetrics = INITIAL_HEALTH;
  private financials: FinancialMetricRecord[] = INITIAL_FINANCIALS;
  private feed: FeedPost[] = INITIAL_FEED;
  private messages: ChatMessage[] = INITIAL_MESSAGES;
  private invites: InviteToken[] = INITIAL_INVITES;
  private audits: AuditLog[] = INITIAL_AUDITS;
  private workflows: WorkflowRule[] = INITIAL_WORKFLOWS;
  private listeners: (() => void)[] = [];

  constructor() {
    this.loadFromLocalStorage();
  }

  private loadFromLocalStorage() {
    if (typeof window === 'undefined') return;
    try {
      const savedRole = localStorage.getItem('mercutrix_role');
      if (savedRole) this.currentRole = savedRole as Role;

      const savedUser = localStorage.getItem('mercutrix_user_id');
      if (savedUser) this.currentUserId = savedUser;

      const savedTasks = localStorage.getItem('mercutrix_tasks');
      if (savedTasks) this.tasks = JSON.parse(savedTasks);

      const savedFeed = localStorage.getItem('mercutrix_feed');
      if (savedFeed) this.feed = JSON.parse(savedFeed);

      const savedMsgs = localStorage.getItem('mercutrix_messages');
      if (savedMsgs) this.messages = JSON.parse(savedMsgs);

      const savedInvites = localStorage.getItem('mercutrix_invites');
      if (savedInvites) this.invites = JSON.parse(savedInvites);
    } catch (e) {
      console.warn('Storage read failed', e);
    }
  }

  private persist() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem('mercutrix_role', this.currentRole);
      localStorage.setItem('mercutrix_user_id', this.currentUserId);
      localStorage.setItem('mercutrix_tasks', JSON.stringify(this.tasks));
      localStorage.setItem('mercutrix_feed', JSON.stringify(this.feed));
      localStorage.setItem('mercutrix_messages', JSON.stringify(this.messages));
      localStorage.setItem('mercutrix_invites', JSON.stringify(this.invites));
    } catch (e) {
      console.warn('Storage write failed', e);
    }
    this.notify();
  }

  subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  // Getters
  getCurrentRole(): Role {
    return this.currentRole;
  }

  setRole(role: Role) {
    this.currentRole = role;
    const matchedProfile = this.profiles.find((p) => p.role === role);
    if (matchedProfile) {
      this.currentUserId = matchedProfile.id;
    }
    this.persist();
  }

  getCurrentUser(): Profile {
    return (
      this.profiles.find((p) => p.id === this.currentUserId) ||
      this.profiles.find((p) => p.role === this.currentRole) ||
      this.profiles[0]
    );
  }

  getCompany() {
    return this.company;
  }

  getProfiles() {
    return this.profiles;
  }

  getRooms() {
    return this.rooms;
  }

  getTasks(roomId?: string) {
    if (roomId) return this.tasks.filter((t) => t.roomId === roomId);
    return this.tasks;
  }

  addTask(task: Omit<TaskItem, 'id' | 'createdAt'>) {
    const newTask: TaskItem = {
      ...task,
      id: `task-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.tasks = [newTask, ...this.tasks];
    this.addAudit('CREATE_TASK', 'TASK', `Created task "${newTask.title}"`);
    this.persist();
    return newTask;
  }

  updateTaskStatus(taskId: string, status: TaskItem['status']) {
    this.tasks = this.tasks.map((t) => (t.id === taskId ? { ...t, status } : t));
    this.persist();
  }

  getHealth() {
    return this.health;
  }

  updateHealth(updates: Partial<HealthMetrics>) {
    this.health = { ...this.health, ...updates };
    this.persist();
  }

  getFinancials() {
    return this.financials;
  }

  getFeed() {
    return this.feed;
  }

  addFeedPost(content: string, type: FeedPost['type'] = 'post') {
    const user = this.getCurrentUser();
    const newPost: FeedPost = {
      id: `post-${Date.now()}`,
      authorId: user.id,
      authorName: user.fullName,
      authorRole: user.role,
      authorAvatar: user.avatarUrl,
      content,
      type,
      likes: 0,
      likedByMe: false,
      comments: [],
      createdAt: new Date().toISOString(),
    };
    this.feed = [newPost, ...this.feed];
    this.persist();
  }

  toggleLikePost(postId: string) {
    this.feed = this.feed.map((p) => {
      if (p.id === postId) {
        const liked = !p.likedByMe;
        return {
          ...p,
          likedByMe: liked,
          likes: liked ? p.likes + 1 : Math.max(0, p.likes - 1),
        };
      }
      return p;
    });
    this.persist();
  }

  addComment(postId: string, content: string) {
    const user = this.getCurrentUser();
    this.feed = this.feed.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          comments: [
            ...p.comments,
            {
              id: `comm-${Date.now()}`,
              postId,
              authorId: user.id,
              authorName: user.fullName,
              content,
              createdAt: new Date().toISOString(),
            },
          ],
        };
      }
      return p;
    });
    this.persist();
  }

  getMessages(roomId: string) {
    return this.messages.filter((m) => m.roomId === roomId);
  }

  addMessage(roomId: string, content: string) {
    const user = this.getCurrentUser();
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      roomId,
      userId: user.id,
      userName: user.fullName,
      userRole: user.role,
      userAvatar: user.avatarUrl,
      content,
      createdAt: new Date().toISOString(),
    };
    this.messages = [...this.messages, newMsg];
    this.persist();
    return newMsg;
  }

  getInvites() {
    return this.invites;
  }

  generateInvite(role: Role, email?: string) {
    const user = this.getCurrentUser();
    const tokenStr = `VIRGO-${role.toUpperCase()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const newInvite: InviteToken = {
      id: `inv-${Date.now()}`,
      token: tokenStr,
      companyId: this.company.id,
      role,
      email,
      createdBy: user.id,
      expiresAt: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
    };
    this.invites = [newInvite, ...this.invites];
    this.addAudit('GENERATE_INVITE', 'INVITE_TOKEN', `Generated invite token ${tokenStr} for role ${role}`);
    this.persist();
    return newInvite;
  }

  getAudits() {
    return this.audits;
  }

  addAudit(action: string, targetType: string, details: string) {
    const user = this.getCurrentUser();
    const newAudit: AuditLog = {
      id: `audit-${Date.now()}`,
      userId: user.id,
      userName: user.fullName,
      action,
      targetType,
      details,
      ipAddress: '192.168.1.100',
      timestamp: new Date().toISOString(),
    };
    this.audits = [newAudit, ...this.audits];
    this.notify();
  }

  getWorkflows() {
    return this.workflows;
  }

  addWorkflow(name: string, trigger: string, action: string) {
    const newWf: WorkflowRule = {
      id: `wf-${Date.now()}`,
      name,
      triggerType: 'health_alert',
      actionType: 'notify_manager',
      trigger,
      action,
      active: true,
      config: { autoCreated: true },
      status: 'active',
      lastRun: new Date().toISOString(),
    };
    this.workflows = [newWf, ...this.workflows];
    this.persist();
    return newWf;
  }

  toggleWorkflow(id: string) {
    this.workflows = this.workflows.map((w) => {
      if (w.id === id) {
        return { ...w, active: !w.active, status: w.active ? 'paused' : 'active' };
      }
      return w;
    });
    this.persist();
  }

  toggleBanUser(userId: string) {
    this.profiles = this.profiles.map((p) => {
      if (p.id === userId) {
        return { ...p, isBanned: !p.isBanned };
      }
      return p;
    });
    this.addAudit('TOGGLE_BAN', 'USER_PROFILE', `Toggled ban state for user ${userId}`);
    this.persist();
  }
}

export const store = new LocalStore();
