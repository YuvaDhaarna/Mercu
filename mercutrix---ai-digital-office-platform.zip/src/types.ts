export type Role =
  | 'founder'
  | 'ceo'
  | 'cfo'
  | 'coo'
  | 'cto'
  | 'cmo'
  | 'chro'
  | 'cio'
  | 'chairman'
  | 'vice_chairman'
  | 'president'
  | 'vice_president'
  | 'managing_director'
  | 'hr'
  | 'manager'
  | 'team_leader'
  | 'supervisor'
  | 'employee'
  | 'intern'
  | 'guest';

export interface Company {
  id: string;
  name: string;
  slug: string;
  createdBy: string;
  createdAt: string;
}

export interface Profile {
  id: string;
  fullName: string;
  email: string;
  avatarUrl?: string;
  role: Role;
  companyId: string;
  departmentId?: string;
  departmentName?: string;
  employeeId: string;
  jobTitle: string;
  phone?: string;
  location?: string;
  bio?: string;
  skills: string[];
  isBanned: boolean;
  isActive: boolean;
  status: 'active' | 'suspended' | 'banned';
  lastLogin: string;
}

export interface Department {
  id: string;
  companyId: string;
  name: string;
  managerId?: string;
  managerName?: string;
  employeeCount: number;
}

export interface OfficeRoom {
  id: string;
  companyId: string;
  name: string;
  slug: string;
  roomType: 'founder' | 'employee' | 'office';
  createdBy: string;
  memberCount: number;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  userRole: Role;
  userAvatar?: string;
  content: string;
  parentId?: string;
  isEdited?: boolean;
  createdAt: string;
}

export interface TaskItem {
  id: string;
  roomId: string;
  title: string;
  description: string;
  assignedTo?: string;
  assignedToName?: string;
  createdBy: string;
  status: 'pending' | 'in_progress' | 'done' | 'archived';
  priority: 'low' | 'medium' | 'high' | 'critical';
  dueDate?: string;
  createdAt: string;
}

export interface CalendarEvent {
  id: string;
  roomId?: string;
  title: string;
  description?: string;
  startsAt: string;
  endsAt: string;
  createdBy: string;
  attendees: string[];
}

export interface HealthMetrics {
  id: string;
  userId: string;
  recordedDate: string;
  steps: number;
  caloriesBurned: number;
  activeMinutes: number;
  sleepHours: number;
  heartRateAvg: number;
  stressLevel: number; // 1-10
  moodScore: number; // 1-10
  energyLevel: number; // 1-10
  focusScore: number; // 1-10
  screenTimeMinutes: number;
  deepWorkMinutes: number;
  breakTaken: number;
}

export interface FinancialMetricRecord {
  id: string;
  period: string;
  revenue: number;
  cogs: number;
  operatingExpenses: number;
  operatingIncome: number;
  interestExpense: number;
  netIncome: number;
  totalAssets: number;
  totalLiabilities: number;
  totalEquity: number;
  operatingCashFlow: number;
  freeCashFlow: number;
  employees: number;
}

export interface FeedPost {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: Role;
  authorAvatar?: string;
  content: string;
  type: 'post' | 'announcement' | 'achievement' | 'milestone';
  likes: number;
  likedByMe?: boolean;
  comments: FeedComment[];
  createdAt: string;
}

export interface FeedComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
}

export interface InviteToken {
  id: string;
  token: string;
  companyId: string;
  role: Role;
  email?: string;
  createdBy: string;
  expiresAt: string;
  usedAt?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  targetType: string;
  details: string;
  ipAddress: string;
  timestamp: string;
}

export interface SecurityAlert {
  id: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  alertType: 'suspicious_login' | 'multiple_failures' | 'unusual_activity' | 'banned_user_attempt';
  userId?: string;
  message: string;
  resolved: boolean;
  timestamp: string;
}

export interface WorkflowRule {
  id: string;
  name: string;
  triggerType: 'task_status' | 'schedule' | 'email_received' | 'health_alert';
  actionType: 'send_message' | 'create_task' | 'notify_manager' | 'generate_report';
  triggerEvent?: string;
  actionExecuted?: string;
  trigger?: string;
  action?: string;
  active: boolean;
  config: Record<string, any>;
  status: 'active' | 'paused' | 'draft';
  lastRun?: string;
}

export type AIProvider = 'gemini' | 'chatgpt' | 'perplexity' | 'claude' | 'deepseek';
