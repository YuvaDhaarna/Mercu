import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', showText = true, className = '' }) => {
  const iconSizeClass =
    size === 'sm' ? 'w-8 h-8' : size === 'lg' ? 'w-12 h-12' : 'w-10 h-10';
  const textClass =
    size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl';

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className={`relative ${iconSizeClass} flex items-center justify-center`}>
        {/* Glowing Emerald Backdrop */}
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500 to-emerald-300 rounded-2xl blur-sm opacity-60 animate-pulse" />

        {/* Outer Frame with Glassmorphism */}
        <div className="relative w-full h-full bg-[#091F18] border border-emerald-400/40 rounded-2xl flex items-center justify-center p-1.5 shadow-lg shadow-emerald-950/50">
          <svg viewBox="0 0 100 100" fill="none" className="w-full h-full">
            <defs>
              <linearGradient id="virgoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#34D399" />
                <stop offset="50%" stopColor="#10B981" />
                <stop offset="100%" stopColor="#065F46" />
              </linearGradient>
              <linearGradient id="leafGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#A7F3D0" />
                <stop offset="100%" stopColor="#34D399" />
              </linearGradient>
            </defs>

            {/* Stylized Female Silhouette (Virgo) */}
            <path
              d="M 42,22 C 42,16 48,12 52,12 C 58,12 62,17 60,23 C 58,28 50,30 46,32 C 40,35 34,42 34,52 C 34,68 46,78 52,86 C 50,86 44,82 40,74 C 36,66 38,56 42,48 C 45,42 50,38 52,32 C 53,28 48,25 42,22 Z"
              fill="url(#virgoGrad)"
            />

            {/* 5-Leaf Plant / Sprout held in hand */}
            {/* Center leaf */}
            <path d="M 60,42 Q 62,26 66,22 Q 70,26 62,44 Z" fill="url(#leafGrad)" />
            {/* Top-right leaf */}
            <path d="M 61,43 Q 74,32 78,34 Q 76,40 63,45 Z" fill="url(#leafGrad)" />
            {/* Top-left leaf */}
            <path d="M 59,42 Q 52,28 48,30 Q 51,36 58,44 Z" fill="url(#leafGrad)" />
            {/* Mid-right leaf */}
            <path d="M 62,45 Q 76,48 78,53 Q 72,56 61,47 Z" fill="url(#leafGrad)" />
            {/* Mid-left leaf */}
            <path d="M 59,45 Q 46,46 44,51 Q 50,54 58,47 Z" fill="url(#leafGrad)" />

            {/* Stem */}
            <path d="M 54,62 Q 58,52 60,42" stroke="#A7F3D0" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-black tracking-wider text-white ${textClass}`}>
              MERCUTRIX
            </span>
            <span className="text-[10px] font-semibold tracking-widest px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              AI
            </span>
          </div>
          <span className="text-[10px] uppercase font-medium tracking-widest text-emerald-400/80">
            Digital Office Engine
          </span>
        </div>
      )}
    </div>
  );
};
