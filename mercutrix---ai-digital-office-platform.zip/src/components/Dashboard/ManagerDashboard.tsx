import React from 'react';
import { Users, CheckCircle, Clock, HeartPulse, Plus } from 'lucide-react';
import { StatCard } from '../shared/StatCard';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { store } from '../../lib/storage';

export const ManagerDashboard: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const profiles = store.getProfiles();
  const tasks = store.getTasks();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0C1A14] to-[#06100C] border border-emerald-500/30">
        <h1 className="text-3xl font-black text-white">Manager & Team Hub</h1>
        <p className="text-sm text-gray-300 mt-2">Team workload distribution, focus scores, and task tracking.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard title="Team Active Members" value={profiles.length} icon={<Users className="w-5 h-5" />} />
        <StatCard title="Open Team Tasks" value={tasks.filter(t => t.status !== 'done').length} icon={<Clock className="w-5 h-5" />} />
        <StatCard title="Avg Team Focus Score" value="92/100" badge="OPTIMAL" icon={<HeartPulse className="w-5 h-5" />} />
      </div>

      <Card className="p-6">
        <h3 className="font-bold text-lg text-white mb-4">Department Workload</h3>
        <div className="space-y-3">
          {tasks.map((t) => (
            <div key={t.id} className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex justify-between items-center text-xs">
              <div>
                <p className="font-bold text-white">{t.title}</p>
                <span className="text-gray-400">Assigned: {t.assignedToName || 'Unassigned'}</span>
              </div>
              <span className={`px-2.5 py-1 rounded font-bold uppercase text-[10px] ${t.status === 'done' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}`}>
                {t.status}
              </span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
