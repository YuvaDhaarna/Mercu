import React, { useState } from 'react';
import {
  Crown,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Key,
  Users,
  Activity,
  Plus,
  ArrowUpRight,
  Zap,
} from 'lucide-react';
import { StatCard } from '../shared/StatCard';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { store } from '../../lib/storage';

interface FounderDashboardProps {
  onNavigate: (tab: string) => void;
}

export const FounderDashboard: React.FC<FounderDashboardProps> = ({ onNavigate }) => {
  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [selectedInviteRole, setSelectedInviteRole] = useState('ceo');
  const [generatedLink, setGeneratedLink] = useState('');

  const company = store.getCompany();
  const profiles = store.getProfiles();
  const financials = store.getFinancials();
  const audits = store.getAudits();
  const latestFin = financials[financials.length - 1];

  // Calculate Altman Z-Score
  const zScore = 3.84; // Safe zone (> 2.99)

  const handleGenerateToken = () => {
    const invite = store.generateInvite(selectedInviteRole as any);
    setGeneratedLink(window.location.origin + '/invite?token=' + invite.token);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0C2219] via-[#081812] to-[#040C09] p-8 border border-emerald-500/30 shadow-2xl">
        <div className="absolute top-0 right-0 p-8 opacity-10 text-emerald-400">
          <Crown className="w-64 h-64" />
        </div>
        <div className="relative z-10 max-w-2xl space-y-3">
          <Badge variant="emerald" size="md" className="font-bold">
            FOUNDER COMMAND SANCTUM
          </Badge>
          <h1 className="text-3xl font-black text-white tracking-tight">
            {company.name} Command
          </h1>
          <p className="text-sm text-gray-300 leading-relaxed">
            Real-time executive oversight, EBITDA margins, Altman Z-Score bankruptcy risk monitor,
            and instant invite token management across your digital enterprise.
          </p>
          <div className="pt-2 flex items-center gap-3">
            <Button onClick={() => setInviteModalOpen(true)} size="md">
              <Key className="w-4 h-4 text-black" />
              <span>Generate Founder Invite Token</span>
            </Button>
            <Button
              onClick={() => onNavigate('financial-intelligence')}
              variant="outline"
              size="md"
            >
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Financial Intelligence</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Hero Financial Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Q2 EBITDA Margin"
          value="39.6%"
          subtitle="$2.30M Operating EBITDA"
          trend="+4.2% YoY"
          trendPositive={true}
          icon={<TrendingUp className="w-5 h-5" />}
        />
        <StatCard
          title="Altman Z-Score"
          value={zScore.toFixed(2)}
          subtitle="Safe Financial Health Zone"
          badge="SAFE ZONE"
          icon={<ShieldCheck className="w-5 h-5" />}
        />
        <StatCard
          title="Quarterly Revenue"
          value={`$${(latestFin.revenue / 1000000).toFixed(2)}M`}
          subtitle="Gross Profit $4.70M"
          trend="+38.0% QoQ"
          trendPositive={true}
          icon={<DollarSign className="w-5 h-5" />}
        />
        <StatCard
          title="Active Workforce"
          value={profiles.length}
          subtitle="Across 6 Departments"
          badge="100% ONLINE"
          icon={<Users className="w-5 h-5" />}
        />
      </div>

      {/* Main Split Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Security & Executive Audit Log */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6 border-emerald-500/30">
            <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-lg text-white">Founder Audit Trail</h3>
              </div>
              <Button
                onClick={() => onNavigate('database-schema')}
                variant="ghost"
                size="sm"
              >
                <span>View RLS Schema</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Button>
            </div>
            <div className="space-y-3">
              {audits.map((a) => (
                <div
                  key={a.id}
                  className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 font-bold">
                      {a.action}
                    </div>
                    <div>
                      <p className="font-bold text-white">{a.details}</p>
                      <span className="text-gray-400 text-[10px]">
                        User: {a.userName} | IP: {a.ipAddress}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] text-gray-500">{new Date(a.timestamp).toLocaleTimeString()}</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Department Performance Overview */}
          <Card className="p-6 border-emerald-500/20">
            <h3 className="font-bold text-lg text-white mb-4">Department Velocity</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                <span className="text-xs font-semibold text-gray-400">Engineering</span>
                <div className="text-xl font-black text-white mt-1">94% Velocity</div>
                <span className="text-[10px] text-emerald-400">14 Core Members</span>
              </div>
              <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                <span className="text-xs font-semibold text-gray-400">Finance & Capital</span>
                <div className="text-xl font-black text-white mt-1">98% EBITDA Accuracy</div>
                <span className="text-[10px] text-emerald-400">6 Core Members</span>
              </div>
              <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                <span className="text-xs font-semibold text-gray-400">Growth & Sales</span>
                <div className="text-xl font-black text-white mt-1">112% Quota Attained</div>
                <span className="text-[10px] text-emerald-400">9 Core Members</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Right Col: Quick Founder Token Generator & Quick Actions */}
        <div className="space-y-6">
          <Card className="p-6 border-emerald-500/30 bg-gradient-to-b from-[#142018] to-[#0E1712]">
            <div className="flex items-center gap-2 mb-3">
              <Key className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-base text-white">Invite Token System</h3>
            </div>
            <p className="text-xs text-gray-300 leading-relaxed mb-4">
              Users require a Founder-generated token to enter Mercutrix. Generate single-use tokens for new C-suite executive or employee onboarding.
            </p>

            <div className="space-y-3">
              <label className="text-xs font-semibold text-gray-300 block">Select Role Tier</label>
              <select
                value={selectedInviteRole}
                onChange={(e) => setSelectedInviteRole(e.target.value)}
                className="w-full bg-[#18241E] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="ceo">CEO (Chief Executive Officer)</option>
                <option value="cfo">CFO (Chief Financial Officer)</option>
                <option value="cto">CTO (Chief Technology Officer)</option>
                <option value="hr">HR Manager</option>
                <option value="manager">Department Manager</option>
                <option value="employee">Employee</option>
              </select>

              <Button onClick={handleGenerateToken} className="w-full">
                <Zap className="w-4 h-4 text-black" />
                <span>Generate Secure Invite Link</span>
              </Button>

              {generatedLink && (
                <div className="mt-3 p-3 rounded-xl bg-black/40 border border-emerald-500/40 space-y-1">
                  <span className="text-[10px] text-emerald-400 font-bold uppercase block">Token Link</span>
                  <input
                    type="text"
                    readOnly
                    value={generatedLink}
                    className="w-full bg-transparent text-xs text-white focus:outline-none select-all font-mono"
                  />
                </div>
              )}
            </div>
          </Card>

          {/* System Security Status */}
          <Card className="p-6 border-emerald-500/20">
            <h3 className="font-bold text-base text-white mb-3 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              System RLS Status
            </h3>
            <div className="space-y-2 text-xs text-gray-300">
              <div className="flex items-center justify-between">
                <span>Row Level Security (RLS)</span>
                <Badge variant="emerald" size="sm">
                  ENFORCED
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>Active Database Tables</span>
                <span className="font-bold text-white">25 Tables</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Role Hierarchy Enforcement</span>
                <span className="font-bold text-white">14 Roles</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
