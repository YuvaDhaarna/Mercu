import React, { useState } from 'react';
import {
  CheckSquare,
  Flame,
  Timer,
  HeartPulse,
  Sparkles,
  Plus,
  Calendar,
  Check,
} from 'lucide-react';
import { StatCard } from '../shared/StatCard';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { store } from '../../lib/storage';

export const EmployeeDashboard: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const [priority1, setPriority1] = useState('Complete Mercury AI orchestrator testing');
  const [priority2, setPriority2] = useState('Review team pull requests & RLS policies');
  const [priority3, setPriority3] = useState('Take 15-min afternoon focus walk');
  const [timerActive, setTimerActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(25 * 60);

  const tasks = store.getTasks();
  const health = store.getHealth();

  const toggleTimer = () => {
    setTimerActive(!timerActive);
  };

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0E1D16] to-[#07130D] border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <Badge variant="emerald" size="md" className="mb-2">
            DAILY REFLECTION & DEEP WORK
          </Badge>
          <h1 className="text-3xl font-black text-white">Personal Workspace</h1>
          <p className="text-sm text-gray-300 mt-1">
            Focus on your top 3 daily priorities, track deep work sessions, and manage tasks.
          </p>
        </div>
        <Button onClick={() => onNavigate('wellness-productivity')} size="md">
          <HeartPulse className="w-4 h-4 text-black" />
          <span>Wellness & Focus Hub</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard title="Daily Focus Score" value={`${health.focusScore}/100`} badge="PEAK FLOW" icon={<Flame className="w-5 h-5" />} />
        <StatCard title="Deep Work Today" value={`${health.deepWorkMinutes} mins`} trend="+20 mins vs avg" icon={<Timer className="w-5 h-5" />} />
        <StatCard title="Daily Step Count" value={health.steps.toLocaleString()} subtitle="Target 10,000" icon={<CheckSquare className="w-5 h-5" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Priorities & Task List */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6 border-emerald-500/30">
            <h3 className="font-bold text-lg text-white mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              Daily Reflection (Top 3 Priorities)
            </h3>
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center justify-center">
                  1
                </span>
                <input
                  type="text"
                  value={priority1}
                  onChange={(e) => setPriority1(e.target.value)}
                  className="bg-transparent text-sm text-white font-medium focus:outline-none w-full"
                />
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center justify-center">
                  2
                </span>
                <input
                  type="text"
                  value={priority2}
                  onChange={(e) => setPriority2(e.target.value)}
                  className="bg-transparent text-sm text-white font-medium focus:outline-none w-full"
                />
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center justify-center">
                  3
                </span>
                <input
                  type="text"
                  value={priority3}
                  onChange={(e) => setPriority3(e.target.value)}
                  className="bg-transparent text-sm text-white font-medium focus:outline-none w-full"
                />
              </div>
            </div>
          </Card>

          {/* Assigned Tasks */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg text-white">My Active Tasks</h3>
              <Button onClick={() => onNavigate('office-rooms')} size="sm">
                <Plus className="w-4 h-4 text-black" />
                <span>Add Task</span>
              </Button>
            </div>
            <div className="space-y-3">
              {tasks.map((t) => (
                <div
                  key={t.id}
                  className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => store.updateTaskStatus(t.id, t.status === 'done' ? 'pending' : 'done')}
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                        t.status === 'done'
                          ? 'bg-emerald-500 border-emerald-500 text-black'
                          : 'border-gray-500 hover:border-emerald-400'
                      }`}
                    >
                      {t.status === 'done' && <Check className="w-3.5 h-3.5" />}
                    </button>
                    <div>
                      <p className={`font-bold ${t.status === 'done' ? 'line-through text-gray-500' : 'text-white'}`}>
                        {t.title}
                      </p>
                      <span className="text-[10px] text-gray-400">{t.description}</span>
                    </div>
                  </div>
                  <Badge variant={t.priority === 'critical' ? 'rose' : 'emerald'} size="sm">
                    {t.priority}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right Col: Deep Work Pomodoro Timer */}
        <div className="space-y-6">
          <Card className="p-6 border-emerald-500/30 text-center bg-gradient-to-b from-[#142219] to-[#0A120E]">
            <Timer className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <h3 className="font-bold text-base text-white">Pomodoro Focus Session</h3>
            <span className="text-xs text-gray-400 block mb-4">25-Minute Deep Focus Loop</span>

            <div className="text-4xl font-black text-white font-mono my-4 tracking-wider">
              {formatTimer(timerSeconds)}
            </div>

            <Button onClick={toggleTimer} className="w-full h-11">
              <span>{timerActive ? 'Pause Session' : 'Start Focus Session'}</span>
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
};
