import React from 'react';
import { LayoutDashboard, TrendingUp, DollarSign, Target, Award, Users } from 'lucide-react';
import { StatCard } from '../shared/StatCard';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { store } from '../../lib/storage';

export const ExecutiveDashboard: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const financials = store.getFinancials();
  const latest = financials[financials.length - 1];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0C1E16] to-[#06120D] border border-emerald-500/30">
        <h1 className="text-3xl font-black text-white">Executive Boardroom</h1>
        <p className="text-sm text-gray-300 mt-2">Strategic alignment, quarterly performance, and capital allocation controls.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard title="Total Revenue (Q2)" value={`$${(latest.revenue / 1000000).toFixed(2)}M`} trend="+38.0%" icon={<DollarSign className="w-5 h-5" />} />
        <StatCard title="Operating Income" value={`$${(latest.operatingIncome / 1000000).toFixed(2)}M`} trend="+42.5%" icon={<TrendingUp className="w-5 h-5" />} />
        <StatCard title="Free Cash Flow" value={`$${(latest.freeCashFlow / 1000000).toFixed(2)}M`} badge="STRONG LIQUIDITY" icon={<Target className="w-5 h-5" />} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-bold text-lg text-white mb-3">Strategic Initiatives</h3>
          <div className="space-y-3 text-xs text-gray-300">
            <div className="p-3 rounded-xl bg-white/5 flex justify-between items-center">
              <span>Mercutrix AI v2.0 Rollout</span>
              <span className="text-emerald-400 font-bold">Completed</span>
            </div>
            <div className="p-3 rounded-xl bg-white/5 flex justify-between items-center">
              <span>Q3 Enterprise Sales Targets</span>
              <span className="text-emerald-400 font-bold">On Track</span>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <h3 className="font-bold text-lg text-white mb-3">Executive Actions</h3>
          <div className="flex flex-col gap-2">
            <Button onClick={() => onNavigate('financial-intelligence')}>Open Financial Intelligence</Button>
            <Button onClick={() => onNavigate('office-rooms')} variant="outline">Join Executive Boardroom</Button>
          </div>
        </Card>
      </div>
    </div>
  );
};
