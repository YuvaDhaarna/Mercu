import React, { useState } from 'react';
import {
  Crown,
  LayoutDashboard,
  DollarSign,
  HeartPulse,
  Building2,
  Share2,
  Workflow,
  BookOpen,
  UserCheck,
  Key,
  ShieldCheck,
  Bot,
  Database,
  ChevronRight,
  Sparkles,
  Users,
} from 'lucide-react';
import { Logo } from '../Logo';
import { store } from '../../lib/storage';
import { Role } from '../../types';
import { getTier, ROLE_DISPLAY_NAMES } from '../../lib/permissions';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  role: Role;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, role }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [showRoleSelector, setShowRoleSelector] = useState(false);

  const navItems = [
    { id: 'founder-room', label: 'Founder Sanctum', icon: Crown, roles: ['founder'] },
    {
      id: 'executive-suite',
      label: 'Executive Boardroom',
      icon: LayoutDashboard,
      roles: ['founder', 'ceo', 'cfo', 'coo', 'cto', 'cmo', 'chro', 'cio', 'chairman', 'president'],
    },
    {
      id: 'financial-intelligence',
      label: 'Financial Engine',
      icon: DollarSign,
      roles: ['founder', 'ceo', 'cfo', 'president', 'chairman', 'coo'],
    },
    {
      id: 'manager-hub',
      label: 'Manager & Team Hub',
      icon: Users,
      roles: ['founder', 'ceo', 'cfo', 'coo', 'cto', 'hr', 'manager', 'team_leader', 'supervisor'],
    },
    { id: 'employee-workspace', label: 'My Workspace', icon: LayoutDashboard, roles: 'all' },
    { id: 'office-rooms', label: 'Office Rooms', icon: Building2, roles: 'all' },
    { id: 'wellness-productivity', label: 'Wellness & Focus', icon: HeartPulse, roles: 'all' },
    { id: 'company-feed', label: 'Company Feed', icon: Share2, roles: 'all' },
    { id: 'google-workspace', label: 'Google Workspace', icon: BookOpen, roles: 'all' },
    { id: 'no-code-automation', label: 'Workflows & Rules', icon: Workflow, roles: 'all' },
    {
      id: 'employee-management',
      label: 'People & Invites',
      icon: UserCheck,
      roles: ['founder', 'ceo', 'cfo', 'hr', 'manager'],
    },
    { id: 'knowledge-wiki', label: 'Knowledge Base', icon: BookOpen, roles: 'all' },
    { id: 'database-schema', label: 'Database & RLS Schema', icon: Database, roles: ['founder', 'cto', 'cio', 'ceo'] },
  ];

  const filteredItems = navItems.filter((item) => {
    if (item.roles === 'all') return true;
    return item.roles.includes(role);
  });

  const tier = getTier(role);

  return (
    <aside
      className={`bg-[#121212] border-r border-emerald-900/30 flex flex-col justify-between transition-all duration-300 z-30 ${
        collapsed ? 'w-20' : 'w-64 md:w-72'
      }`}
    >
      <div>
        {/* Header Logo */}
        <div className="p-5 flex items-center justify-between border-b border-emerald-900/30">
          <Logo size={collapsed ? 'sm' : 'md'} showText={!collapsed} />
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:bg-emerald-500/10 text-slate-400 hover:text-emerald-400 text-xs transition-colors"
            title="Toggle Sidebar"
          >
            <ChevronRight className={`w-4 h-4 transition-transform ${collapsed ? '' : 'rotate-180'}`} />
          </button>
        </div>

        {/* Role Switcher Pill */}
        {!collapsed && (
          <div className="px-3.5 py-2.5 mx-3 my-3 rounded-xl bg-slate-900/80 border border-emerald-900/30">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 text-[10px] uppercase tracking-wider font-bold">Active Role</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px] tracking-wider border border-emerald-500/30">
                TIER {tier}
              </span>
            </div>
            <button
              onClick={() => setShowRoleSelector(!showRoleSelector)}
              className="mt-1 w-full flex items-center justify-between font-bold text-slate-200 text-xs hover:text-emerald-400 text-left transition-colors"
            >
              <span className="truncate">{ROLE_DISPLAY_NAMES[role]}</span>
              <span className="text-[10px] text-emerald-400 underline">Switch</span>
            </button>

            {/* Quick Role Switcher Dropdown */}
            {showRoleSelector && (
              <div className="mt-2.5 p-2 bg-[#0B0B0B] border border-emerald-900/40 rounded-xl space-y-1 max-h-48 overflow-y-auto">
                {(['founder', 'ceo', 'cfo', 'cto', 'hr', 'manager', 'employee'] as Role[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => {
                      store.setRole(r);
                      setShowRoleSelector(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      role === r
                        ? 'bg-emerald-500 text-slate-900 font-bold'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {ROLE_DISPLAY_NAMES[r]}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Navigation Section Label */}
        {!collapsed && (
          <div className="px-4 mt-2 mb-1 text-[10px] uppercase text-slate-500 font-bold tracking-widest">
            Core Modules
          </div>
        )}

        {/* Navigation Items */}
        <nav className="px-3 space-y-1 overflow-y-auto max-h-[calc(100vh-230px)]">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500/10 text-emerald-400 border-l-2 border-emerald-500 rounded-r font-semibold'
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200 rounded'
                }`}
                title={collapsed ? item.label : undefined}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer Intelligence Block */}
      <div className="p-3 border-t border-slate-800 bg-[#0B0B0B]/80">
        {!collapsed ? (
          <div className="p-3 bg-emerald-950/20 rounded-lg border border-emerald-900/30">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-tighter">
                Mercury AI Online
              </span>
            </div>
            <p className="text-[10px] text-slate-500 leading-tight mb-2">
              Orchestrating Gemini Intelligence Engine...
            </p>
            <button
              onClick={() => setActiveTab('mercury-ai')}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold tracking-wider uppercase transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Launch Assistant</span>
            </button>
          </div>
        ) : (
          <button
            onClick={() => setActiveTab('mercury-ai')}
            className="w-full p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center"
            title="Mercury AI Assistant"
          >
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </button>
        )}
      </div>
    </aside>
  );
};
