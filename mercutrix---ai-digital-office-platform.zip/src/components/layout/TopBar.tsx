import React, { useState } from 'react';
import {
  Search,
  Bell,
  Sparkles,
  Shield,
  User,
  CheckCircle,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';
import { Badge } from '../shared/Badge';
import { Button } from '../shared/Button';
import { Profile, Role } from '../../types';
import { ROLE_DISPLAY_NAMES } from '../../lib/permissions';

interface TopBarProps {
  currentUser: Profile;
  onOpenMercuryAI: () => void;
  onSearch: (query: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentUser,
  onOpenMercuryAI,
  onSearch,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = [
    { id: 1, text: 'Q2 EBITDA Margin report verified by CFO', time: '10m ago' },
    { id: 2, text: 'New Founder Invite Token generated for C-Suite', time: '1h ago' },
    { id: 3, text: 'Google Workspace OAuth scopes auto-refreshed', time: '2h ago' },
  ];

  return (
    <header className="h-14 border-b border-slate-800/50 flex items-center justify-between px-6 md:px-8 bg-[#0B0B0B]/80 backdrop-blur-md sticky top-0 z-20">
      {/* Global Title & Search Bar */}
      <div className="flex items-center gap-6">
        <h1 className="text-base font-semibold tracking-tight text-slate-100 hidden sm:block">
          Global Command <span className="text-slate-500 font-normal">/ {ROLE_DISPLAY_NAMES[currentUser.role]}</span>
        </h1>
        <div className="h-4 w-px bg-slate-800 hidden md:block" />
        <div className="relative w-48 sm:w-64 md:w-80">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              onSearch(e.target.value);
            }}
            placeholder="Search Mercutrix Intelligence..."
            className="w-full bg-slate-900 border border-slate-800 rounded-full pl-9 pr-14 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 text-[10px] uppercase font-bold tracking-widest pointer-events-none hidden sm:block">
            CMD+K
          </span>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-4">
        {/* Workspace Presence Indicators */}
        <div className="hidden lg:flex items-center gap-4 text-xs text-slate-400 font-medium">
          <span className="flex items-center gap-1.5 text-[11px]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>184 Employees Online</span>
          </span>
          <span className="flex items-center gap-1.5 text-[11px]">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-500"></span>
            <span>12 Rooms Active</span>
          </span>
        </div>

        {/* Mercury AI Trigger Button */}
        <button
          onClick={onOpenMercuryAI}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-900 font-bold text-xs shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-slate-900" />
          <span>Mercury AI</span>
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 relative transition-colors"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-[#121212] border border-slate-800 rounded-2xl p-4 shadow-2xl z-50 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-xs uppercase text-slate-300 tracking-wider">Signals & Alerts</span>
                <Badge variant="emerald" size="sm">
                  3 New
                </Badge>
              </div>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {notifications.map((n) => (
                  <div key={n.id} className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-300">
                    <p>{n.text}</p>
                    <span className="text-[10px] text-emerald-400 font-mono mt-1 block">{n.time}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Badge Profile */}
        <div className="flex items-center gap-3 pl-3 border-l border-slate-800">
          <img
            src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250'}
            alt={currentUser.fullName}
            className="w-8 h-8 rounded-full object-cover border border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.2)]"
          />
          <div className="hidden sm:flex flex-col text-left">
            <span className="text-xs font-bold text-slate-200 leading-tight">{currentUser.fullName}</span>
            <span className="text-[10px] text-emerald-400 uppercase font-semibold">
              {ROLE_DISPLAY_NAMES[currentUser.role]}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
