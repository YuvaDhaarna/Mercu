import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  Mic,
  Volume2,
  DollarSign,
  HeartPulse,
  Workflow,
  CheckCircle2,
  ShieldAlert,
  X,
  Zap,
} from 'lucide-react';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { Card } from '../shared/Card';
import { AIProvider, Role } from '../../types';
import { askMercuryAI } from '../../lib/ai';

interface MercuryAIPanelProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: Role;
}

export const MercuryAIPanel: React.FC<MercuryAIPanelProps> = ({
  isOpen,
  onClose,
  currentRole,
}) => {
  const [provider, setProvider] = useState<AIProvider>('gemini');
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<
    { sender: 'user' | 'mercury'; text: string; provider?: string; model?: string }[]
  >([
    {
      sender: 'mercury',
      text: `👋 Greetings! I am **Mercury AI**, your intelligent Digital Office co-pilot adapted for the **${currentRole.toUpperCase()}** role. How can I assist your strategy, finances, health, or workflows today?`,
      provider: 'Gemini',
      model: 'Gemini 3.6 Flash',
    },
  ]);

  if (!isOpen) return null;

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userText = input;
    setInput('');
    setMessages((prev) => [...prev, { sender: 'user', text: userText }]);
    setLoading(true);

    try {
      const response = await askMercuryAI({
        prompt: userText,
        provider,
        role: currentRole,
      });

      setMessages((prev) => [
        ...prev,
        {
          sender: 'mercury',
          text: response.result,
          provider: response.provider,
          model: response.model,
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'mercury',
          text: 'I analyzed your query. Strategic response ready.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickPrompt = (promptText: string) => {
    setInput(promptText);
  };

  const toggleVoice = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setTimeout(() => {
        setInput('Analyze Q2 EBITDA margins and bankruptcy risk Z-Score');
        setIsListening(false);
      }, 2000);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-[#0C130F] border-l border-emerald-500/30 shadow-2xl flex flex-col backdrop-blur-xl animate-slide-in">
      {/* Header */}
      <div className="p-5 border-b border-white/10 bg-[#121B15] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              Mercury AI Engine
            </h3>
            <span className="text-xs text-emerald-400 font-medium">
              Role: {currentRole.toUpperCase()} Persona Active
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-xl text-gray-400 hover:text-white hover:bg-white/10"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Provider Selector Tabs */}
      <div className="px-5 py-3 border-b border-white/10 bg-[#090F0C] flex items-center gap-1.5 overflow-x-auto">
        {(['gemini', 'chatgpt', 'perplexity', 'claude', 'deepseek'] as AIProvider[]).map((p) => (
          <button
            key={p}
            onClick={() => setProvider(p)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all cursor-pointer whitespace-nowrap ${
              provider === p
                ? 'bg-emerald-500 text-black font-bold shadow-md shadow-emerald-500/20'
                : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'
            }`}
          >
            {p}
          </button>
        ))}
      </div>

      {/* Quick Prompt Suggestion Pills */}
      <div className="px-5 py-2.5 border-b border-white/10 bg-[#0E1712] flex items-center gap-2 overflow-x-auto">
        <button
          onClick={() => handleQuickPrompt('Run EBITDA & DCF valuation overview')}
          className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] font-medium flex items-center gap-1 hover:bg-emerald-500/20 whitespace-nowrap"
        >
          <DollarSign className="w-3 h-3 text-emerald-400" /> Financial Intelligence
        </button>
        <button
          onClick={() => handleQuickPrompt('Give me a wellness & focus score summary')}
          className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] font-medium flex items-center gap-1 hover:bg-emerald-500/20 whitespace-nowrap"
        >
          <HeartPulse className="w-3 h-3 text-emerald-400" /> Focus & Health
        </button>
        <button
          onClick={() => handleQuickPrompt('Create an automated task & schedule Google Meet')}
          className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] font-medium flex items-center gap-1 hover:bg-emerald-500/20 whitespace-nowrap"
        >
          <Workflow className="w-3 h-3 text-emerald-400" /> Auto-Workflows
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 p-5 overflow-y-auto space-y-4">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-emerald-500 text-black font-semibold rounded-br-none'
                  : 'bg-[#151E18] border border-emerald-500/30 text-gray-200 rounded-bl-none shadow-lg'
              }`}
            >
              {m.sender === 'mercury' && (
                <div className="flex items-center justify-between mb-2 pb-2 border-b border-white/10 text-[10px]">
                  <span className="font-bold text-emerald-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Mercury AI ({m.model || 'Gemini'})
                  </span>
                  <Badge variant="emerald" size="sm">
                    {m.provider || provider}
                  </Badge>
                </div>
              )}
              <div className="whitespace-pre-wrap">{m.text}</div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-xs text-emerald-400 animate-pulse">
            <Bot className="w-4 h-4 animate-spin" />
            <span>Mercury AI reasoning in progress...</span>
          </div>
        )}
      </div>

      {/* Voice & Text Input Bar */}
      <div className="p-4 border-t border-white/10 bg-[#0F1712]">
        <div className="flex items-center gap-2">
          <button
            onClick={toggleVoice}
            className={`p-3 rounded-xl border transition-all ${
              isListening
                ? 'bg-rose-500/20 border-rose-500 text-rose-400 animate-pulse'
                : 'bg-white/5 border-white/10 text-gray-300 hover:text-white'
            }`}
            title="Speech Input"
          >
            <Mic className="w-4 h-4" />
          </button>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={isListening ? 'Listening to voice...' : 'Ask Mercury AI anything...'}
            className="flex-1 bg-[#18231C] border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
          />
          <Button onClick={handleSend} disabled={loading} size="md" className="p-3">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};
