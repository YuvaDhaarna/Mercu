import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({ children, className = '', glow = false, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`rounded-2xl border border-emerald-900/20 bg-[#121212] glass-morphism shadow-2xl transition-all duration-300 relative overflow-hidden ${
        glow ? 'shadow-[0_0_25px_rgba(16,185,129,0.15)] border-emerald-500/40' : 'hover:border-emerald-900/40'
      } ${onClick ? 'cursor-pointer hover:translate-y-[-2px]' : ''} ${className}`}
    >
      {children}
    </div>
  );
};
