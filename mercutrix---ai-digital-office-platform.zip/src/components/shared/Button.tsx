import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  className = '',
  disabled,
  ...props
}) => {
  const sizeClasses =
    size === 'sm'
      ? 'px-3 py-1.5 text-xs'
      : size === 'lg'
      ? 'px-6 py-3 text-base'
      : 'px-4 py-2 text-sm';

  const variantClasses = {
    primary:
      'bg-emerald-500 hover:bg-emerald-400 text-slate-900 font-bold shadow-[0_0_20px_rgba(16,185,129,0.3)] active:scale-95 border border-emerald-400',
    secondary:
      'bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium active:scale-95 border border-slate-700',
    outline:
      'border border-emerald-900/50 hover:border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10 active:scale-95',
    danger:
      'bg-rose-600 hover:bg-rose-500 text-white font-medium shadow-md shadow-rose-600/20 active:scale-95',
    ghost:
      'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 active:scale-95',
  };

  return (
    <button
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 rounded-xl transition-all duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap ${sizeClasses} ${variantClasses[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};
