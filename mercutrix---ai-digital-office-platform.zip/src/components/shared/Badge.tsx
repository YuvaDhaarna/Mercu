import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'emerald' | 'blue' | 'amber' | 'rose' | 'purple' | 'gray';
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'emerald',
  size = 'md',
  className = '',
}) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';

  const variantClasses = {
    emerald: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold uppercase',
    blue: 'bg-sky-500/20 text-sky-400 border border-sky-500/30 font-bold uppercase',
    amber: 'bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold uppercase',
    rose: 'bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold uppercase',
    purple: 'bg-purple-500/20 text-purple-400 border border-purple-500/30 font-bold uppercase',
    gray: 'bg-slate-800 text-slate-300 border border-slate-700 font-bold uppercase',
  };

  return (
    <span
      className={`inline-flex items-center gap-1 font-semibold rounded-lg tracking-wide whitespace-nowrap ${sizeClasses} ${variantClasses[variant]} ${className}`}
    >
      {children}
    </span>
  );
};
