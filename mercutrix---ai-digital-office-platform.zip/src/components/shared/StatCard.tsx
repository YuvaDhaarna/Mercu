import React from 'react';
import { Card } from './Card';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  trend?: string;
  trendPositive?: boolean;
  icon?: React.ReactNode;
  badge?: string;
  accentColor?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  trend,
  trendPositive = true,
  icon,
  badge,
}) => {
  return (
    <Card className="p-5 border-emerald-900/20 bg-[#121212] relative overflow-hidden">
      <div className="flex items-start justify-between">
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-emerald-500">
            {title}
          </span>
          <div className="text-3xl font-bold text-slate-100 tracking-tighter">{value}</div>
        </div>
        {icon && (
          <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-emerald-400">
            {icon}
          </div>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between text-xs">
        {subtitle && <span className="text-slate-400 text-xs">{subtitle}</span>}
        {trend && (
          <span
            className={`font-semibold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider ${
              trendPositive ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/15 text-rose-400 border border-rose-500/20'
            }`}
          >
            {trend}
          </span>
        )}
        {badge && (
          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            {badge}
          </span>
        )}
      </div>
    </Card>
  );
};
