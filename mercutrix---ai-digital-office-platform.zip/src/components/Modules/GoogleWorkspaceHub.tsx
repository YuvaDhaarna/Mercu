import React, { useState } from 'react';
import {
  Mail,
  HardDrive,
  Calendar as CalendarIcon,
  FileText,
  Table,
  Presentation,
  Video,
  CheckSquare,
  StickyNote,
  Users,
  CheckCircle,
  ExternalLink,
  RefreshCw,
  Plus,
} from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';

export const GoogleWorkspaceHub: React.FC = () => {
  const [activeApp, setActiveTab] = useState<'gmail' | 'drive' | 'calendar' | 'docs' | 'meet'>('gmail');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);

  const mockFiles = [
    { id: '1', name: 'Q2_Financial_Valuation_Report.pdf', type: 'PDF', size: '2.4 MB', modified: '2 hours ago' },
    { id: '2', name: 'Executive_Board_Deck_2026.gslide', type: 'Slides', size: '5.1 MB', modified: 'Yesterday' },
    { id: '3', name: 'Mercutrix_Architecture_Blueprint.gdoc', type: 'Doc', size: '1.2 MB', modified: '3 days ago' },
  ];

  const handleSendEmail = () => {
    if (!emailSubject.trim()) return;
    setSentSuccess(true);
    setTimeout(() => {
      setEmailSubject('');
      setEmailBody('');
      setSentSuccess(false);
    }, 2500);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0C1F17] via-[#071610] to-[#040C08] border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <Badge variant="emerald" size="md" className="mb-2">
            GOOGLE WORKSPACE UNIFIED HUB
          </Badge>
          <h1 className="text-3xl font-black text-white">Gmail, Drive, Calendar & Workspace APIs</h1>
          <p className="text-sm text-gray-300 mt-1">
            Seamless OAuth integration to read, summarize, draft, create, and manage your Google Workspace environment.
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>OAuth Scopes Granted & Active</span>
        </div>
      </div>

      {/* App Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setActiveTab('gmail')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeApp === 'gmail'
              ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
              : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white border border-white/10'
          }`}
        >
          <Mail className="w-4 h-4" /> Gmail Integration
        </button>
        <button
          onClick={() => setActiveTab('drive')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeApp === 'drive'
              ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
              : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white border border-white/10'
          }`}
        >
          <HardDrive className="w-4 h-4" /> Google Drive & Documents
        </button>
        <button
          onClick={() => setActiveTab('calendar')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeApp === 'calendar'
              ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
              : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white border border-white/10'
          }`}
        >
          <CalendarIcon className="w-4 h-4" /> Google Calendar
        </button>
      </div>

      {/* View Switch */}
      {activeApp === 'gmail' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Gmail Reader & AI Summarizer */}
          <Card className="p-6 border-emerald-500/30">
            <h3 className="font-bold text-lg text-white mb-3">Gmail Inbox & AI Summarizer</h3>
            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                <div className="flex justify-between font-bold text-white">
                  <span>Board Meeting Schedule Confirmation</span>
                  <span className="text-[10px] text-emerald-400">Today, 10:30 AM</span>
                </div>
                <p className="text-gray-300">Aria, confirming tomorrow's Q3 capital allocation review with Board directors...</p>
              </div>
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                <div className="flex justify-between font-bold text-white">
                  <span>Google Cloud Enterprise Tier Grant</span>
                  <span className="text-[10px] text-emerald-400">Yesterday</span>
                </div>
                <p className="text-gray-300">Your $100,000 Cloud Run credits have been provisioned for Mercutrix backend infrastructure...</p>
              </div>
            </div>
          </Card>

          {/* Draft & Send Email */}
          <Card className="p-6 border-emerald-500/30">
            <h3 className="font-bold text-lg text-white mb-3">Draft & Send via Gmail API</h3>
            {sentSuccess && (
              <div className="p-3 mb-3 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold flex items-center gap-2">
                <CheckCircle className="w-4 h-4" /> Email dispatched via Gmail OAuth API!
              </div>
            )}
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-300 block mb-1">Subject</label>
                <input
                  type="text"
                  value={emailSubject}
                  onChange={(e) => setEmailSubject(e.target.value)}
                  placeholder="e.g. Q3 Financial Update & Board Briefing"
                  className="w-full bg-[#18231C] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                />
              </div>
              <div>
                <label className="text-xs text-gray-300 block mb-1">Message Body</label>
                <textarea
                  rows={4}
                  value={emailBody}
                  onChange={(e) => setEmailBody(e.target.value)}
                  placeholder="Draft your email message..."
                  className="w-full bg-[#18231C] border border-white/10 rounded-xl p-3.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                />
              </div>
              <Button onClick={handleSendEmail} className="w-full">
                <Mail className="w-4 h-4 text-black" />
                <span>Send Email via Gmail</span>
              </Button>
            </div>
          </Card>
        </div>
      )}

      {activeApp === 'drive' && (
        <Card className="p-6 border-emerald-500/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-white">Google Drive Workspace Files</h3>
            <Button size="sm">
              <Plus className="w-4 h-4 text-black" />
              <span>Create Google Doc</span>
            </Button>
          </div>
          <div className="space-y-3">
            {mockFiles.map((f) => (
              <div key={f.id} className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 font-bold">
                    {f.type}
                  </div>
                  <div>
                    <p className="font-bold text-white">{f.name}</p>
                    <span className="text-[10px] text-gray-400">Size: {f.size} | Modified: {f.modified}</span>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <span>Open in Drive</span>
                  <ExternalLink className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}

      {activeApp === 'calendar' && (
        <Card className="p-6 border-emerald-500/30">
          <h3 className="font-bold text-lg text-white mb-4">Google Calendar Schedule</h3>
          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
              <div>
                <span className="font-bold text-emerald-400">10:00 AM - 11:00 AM</span>
                <p className="font-bold text-white mt-0.5">Q3 Financial DCF Valuation Sync (CFO & Founder)</p>
              </div>
              <Badge variant="emerald" size="sm">Google Meet Linked</Badge>
            </div>
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div>
                <span className="font-bold text-gray-400">02:00 PM - 03:00 PM</span>
                <p className="font-bold text-white mt-0.5">Engineering Architecture & Mercury AI Failover</p>
              </div>
              <Badge variant="gray" size="sm">Internal</Badge>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};
