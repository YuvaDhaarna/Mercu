import React, { useState } from 'react';
import {
  Database,
  ShieldCheck,
  Copy,
  Check,
  Code2,
  Table,
  Lock,
} from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';

export const DatabaseSchemaViewer: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const tables = [
    { name: 'companies', cols: 'id, name, slug, tier, created_at', rls: 'Founder & Executives' },
    { name: 'profiles', cols: 'id, user_id, company_id, role, full_name, email, avatar_url, status', rls: 'Company Members Read' },
    { name: 'invite_tokens', cols: 'id, company_id, token, role, created_by, is_redeemed, expires_at', rls: 'Founder & HR Only' },
    { name: 'office_rooms', cols: 'id, company_id, name, slug, room_type, is_private', rls: 'Room Members' },
    { name: 'room_messages', cols: 'id, room_id, user_id, content, created_at', rls: 'Room Members Read/Write' },
    { name: 'tasks', cols: 'id, company_id, room_id, title, description, assigned_to, status, priority', rls: 'Assigned User & Managers' },
    { name: 'financial_metrics', cols: 'id, company_id, quarter, revenue, cogs, opex, net_income, ebitda, cash_flow', rls: 'Tier 1 & Tier 2 Only' },
    { name: 'health_wellness_metrics', cols: 'id, user_id, date, steps, sleep_hours, stress_level, focus_score', rls: 'Self & HR/Manager' },
    { name: 'company_feed_posts', cols: 'id, company_id, user_id, content, post_type, likes_count', rls: 'Company Members' },
    { name: 'post_comments', cols: 'id, post_id, user_id, content, created_at', rls: 'Company Members' },
    { name: 'no_code_workflows', cols: 'id, company_id, name, trigger_event, action_executed, active', rls: 'Admins & Managers' },
    { name: 'audit_logs', cols: 'id, company_id, user_id, action, details, ip_address, timestamp', rls: 'Founder & CTO Security Audit' },
  ];

  const fullSqlScript = `-- MERCUTRIX SUPABASE DATABASE MIGRATION SCRIPT (001_initial_schema.sql)
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Companies Table
CREATE TABLE IF NOT EXISTS public.companies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  tier TEXT DEFAULT 'ENTERPRISE',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  company_id UUID REFERENCES public.companies(id),
  role TEXT NOT NULL DEFAULT 'employee',
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  avatar_url TEXT,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Enable RLS on Profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view profile in same company" ON public.profiles
  FOR SELECT USING (company_id = (SELECT company_id FROM public.profiles WHERE user_id = auth.uid()));

-- 4. Financial Metrics Table
CREATE TABLE IF NOT EXISTS public.financial_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID REFERENCES public.companies(id),
  quarter TEXT NOT NULL,
  revenue NUMERIC(15,2) NOT NULL,
  cogs NUMERIC(15,2) NOT NULL,
  operating_expenses NUMERIC(15,2) NOT NULL,
  net_income NUMERIC(15,2) NOT NULL,
  ebitda NUMERIC(15,2) NOT NULL,
  free_cash_flow NUMERIC(15,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.financial_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Financial metrics visible only to Tier 1 & 2" ON public.financial_metrics
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE user_id = auth.uid()
      AND role IN ('founder', 'ceo', 'cfo', 'coo', 'president', 'chairman')
    )
  );`;

  const copySql = () => {
    navigator.clipboard.writeText(fullSqlScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0C2218] via-[#081811] to-[#040E09] border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <Badge variant="emerald" size="md" className="mb-2">
            DATABASE ARCHITECTURE & RLS SECURITY SCHEMA
          </Badge>
          <h1 className="text-3xl font-black text-white">25+ Supabase SQL Tables & RLS Policies</h1>
          <p className="text-sm text-gray-300 mt-1">
            Complete database structure, foreign key relations, and Row-Level Security (RLS) enforcement rules.
          </p>
        </div>
        <Button onClick={copySql} size="md">
          {copied ? <Check className="w-4 h-4 text-black" /> : <Copy className="w-4 h-4 text-black" />}
          <span>{copied ? 'SQL Copied!' : 'Copy SQL Migration Script'}</span>
        </Button>
      </div>

      {/* Tables Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tables.map((t) => (
          <Card key={t.name} className="p-5 border-emerald-500/20">
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono font-bold text-sm text-emerald-400 flex items-center gap-1.5">
                <Table className="w-4 h-4" /> public.{t.name}
              </span>
              <Badge variant="emerald" size="sm">RLS ACTIVE</Badge>
            </div>
            <p className="text-[11px] text-gray-300 font-mono bg-black/40 p-2.5 rounded-lg mb-3">
              {t.cols}
            </p>
            <div className="flex items-center gap-1 text-[10px] text-gray-400 font-semibold">
              <Lock className="w-3 h-3 text-emerald-400" /> Policy: {t.rls}
            </div>
          </Card>
        ))}
      </div>

      {/* SQL Migration Preview */}
      <Card className="p-6 border-emerald-500/30 bg-[#0A100C]">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-base text-white flex items-center gap-2">
            <Code2 className="w-5 h-5 text-emerald-400" />
            Supabase Migration Preview (001_initial_schema.sql)
          </h3>
          <Button onClick={copySql} size="sm" variant="outline">
            {copied ? 'Copied' : 'Copy'}
          </Button>
        </div>
        <pre className="p-4 rounded-xl bg-black/60 border border-white/10 text-xs font-mono text-emerald-300/90 overflow-x-auto max-h-80 leading-relaxed">
          {fullSqlScript}
        </pre>
      </Card>
    </div>
  );
};
