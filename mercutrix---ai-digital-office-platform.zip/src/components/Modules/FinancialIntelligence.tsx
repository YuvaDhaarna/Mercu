import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Calculator,
  Building,
  FileText,
  Sparkles,
  PieChart,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import { StatCard } from '../shared/StatCard';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { store } from '../../lib/storage';

export const FinancialIntelligence: React.FC = () => {
  const [discountRate, setDiscountRate] = useState(9.5);
  const [terminalGrowth, setTerminalGrowth] = useState(3.0);
  const [policyTopic, setPolicyTopic] = useState('tax');

  const financials = store.getFinancials();
  const latest = financials[financials.length - 1];

  const ebitda = latest.operatingIncome + latest.interestExpense;
  const ebitdaMargin = (ebitda / latest.revenue) * 100;
  const grossMargin = ((latest.revenue - latest.cogs) / latest.revenue) * 100;
  const netMargin = (latest.netIncome / latest.revenue) * 100;
  const debtToEquity = latest.totalLiabilities / latest.totalEquity;

  // DCF Valuation Calculation
  const projectedCashFlows = [
    latest.freeCashFlow * 1.15,
    latest.freeCashFlow * 1.30,
    latest.freeCashFlow * 1.48,
    latest.freeCashFlow * 1.68,
    latest.freeCashFlow * 1.90,
  ];

  const presentValues = projectedCashFlows.map((cf, i) => cf / Math.pow(1 + discountRate / 100, i + 1));
  const pvSum = presentValues.reduce((a, b) => a + b, 0);
  const terminalValue = (projectedCashFlows[4] * (1 + terminalGrowth / 100)) / (discountRate / 100 - terminalGrowth / 100);
  const pvTerminalValue = terminalValue / Math.pow(1 + discountRate / 100, 5);
  const dcfValuation = pvSum + pvTerminalValue;

  const chartData = [
    { period: '2025 Q3', revenue: 2.8, ebitda: 1.0, fcf: 0.8 },
    { period: '2025 Q4', revenue: 3.4, ebitda: 1.3, fcf: 1.0 },
    { period: '2026 Q1', revenue: 4.2, ebitda: 1.8, fcf: 1.25 },
    { period: '2026 Q2', revenue: 5.8, ebitda: 2.3, fcf: 1.72 },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0B2017] via-[#071710] to-[#040C08] border border-emerald-500/30">
        <Badge variant="emerald" size="md" className="mb-2">
          CFO & FOUNDER FINANCIAL INTELLIGENCE ENGINE
        </Badge>
        <h1 className="text-3xl font-black text-white">Financial Analytics & Valuation</h1>
        <p className="text-sm text-gray-300 mt-1">
          Automated Profit & Loss, EBITDA margins, Altman Z-Score bankruptcy risk analysis, and 5-Year DCF enterprise valuation modeling.
        </p>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Gross Margin" value={`${grossMargin.toFixed(1)}%`} subtitle="SaaS Benchmark 80%+" trend="+2.4%" icon={<DollarSign className="w-5 h-5" />} />
        <StatCard title="EBITDA Margin" value={`${ebitdaMargin.toFixed(1)}%`} subtitle={`$${(ebitda / 1000000).toFixed(2)}M EBITDA`} trend="+4.1%" icon={<TrendingUp className="w-5 h-5" />} />
        <StatCard title="Debt-to-Equity Ratio" value={debtToEquity.toFixed(2)} subtitle="Target < 0.8" badge="LOW RISK" icon={<ShieldCheck className="w-5 h-5" />} />
        <StatCard title="5-Year DCF Valuation" value={`$${(dcfValuation / 1000000).toFixed(1)}M`} subtitle={`WACC ${discountRate}%`} badge="AI VALUED" icon={<Calculator className="w-5 h-5" />} />
      </div>

      {/* Chart & Valuation Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Revenue & EBITDA Trend */}
        <Card className="lg:col-span-2 p-6 border-emerald-500/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-white">Quarterly Revenue & EBITDA Trajectory ($M)</h3>
            <Badge variant="emerald" size="sm">LIVE METRICS</Badge>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="period" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip contentStyle={{ backgroundColor: '#111813', borderColor: '#10B981' }} />
                <Area type="monotone" dataKey="revenue" stroke="#10B981" fillOpacity={1} fill="url(#revGrad)" />
                <Area type="monotone" dataKey="ebitda" stroke="#34D399" fillOpacity={0.2} fill="#34D399" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Right Col: Interactive DCF Valuation Calculator */}
        <Card className="p-6 border-emerald-500/30 bg-gradient-to-b from-[#132018] to-[#0A120D]">
          <h3 className="font-bold text-base text-white mb-2 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-400" />
            Interactive DCF Valuation Engine
          </h3>
          <p className="text-xs text-gray-300 mb-4">Adjust WACC discount rate and terminal growth rate to update enterprise valuation in real time.</p>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs text-gray-300 mb-1">
                <span>WACC Discount Rate</span>
                <span className="font-bold text-emerald-400">{discountRate}%</span>
              </div>
              <input
                type="range"
                min="6"
                max="15"
                step="0.5"
                value={discountRate}
                onChange={(e) => setDiscountRate(parseFloat(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-gray-300 mb-1">
                <span>Terminal Growth Rate</span>
                <span className="font-bold text-emerald-400">{terminalGrowth}%</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                step="0.5"
                value={terminalGrowth}
                onChange={(e) => setTerminalGrowth(parseFloat(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-emerald-500/30 text-center space-y-1">
              <span className="text-[10px] uppercase text-gray-400 font-semibold">Estimated Enterprise DCF Value</span>
              <div className="text-2xl font-black text-emerald-400">
                ${(dcfValuation / 1000000).toFixed(2)}M
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* P&L Breakdown Table & Bank/Government Policy Analyzer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 border-emerald-500/20">
          <h3 className="font-bold text-lg text-white mb-4">Profit & Loss (P&L) Statement (Q2 2026)</h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between p-2 rounded bg-white/5 font-bold text-white">
              <span>Gross Revenue</span>
              <span>${latest.revenue.toLocaleString()}</span>
            </div>
            <div className="flex justify-between p-2 rounded text-gray-400">
              <span>Cost of Goods Sold (COGS)</span>
              <span>-${latest.cogs.toLocaleString()}</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-emerald-500/10 font-bold text-emerald-300">
              <span>Gross Profit</span>
              <span>${(latest.revenue - latest.cogs).toLocaleString()}</span>
            </div>
            <div className="flex justify-between p-2 rounded text-gray-400">
              <span>Operating Expenses (OPEX)</span>
              <span>-${latest.operatingExpenses.toLocaleString()}</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-emerald-500/15 font-black text-white">
              <span>Operating Income (EBIT)</span>
              <span>${latest.operatingIncome.toLocaleString()}</span>
            </div>
            <div className="flex justify-between p-2 rounded text-gray-400">
              <span>Net Income After Interest</span>
              <span>${latest.netIncome.toLocaleString()}</span>
            </div>
          </div>
        </Card>

        {/* Bank & Policy Intelligence */}
        <Card className="p-6 border-emerald-500/20">
          <h3 className="font-bold text-lg text-white mb-2 flex items-center gap-2">
            <Building className="w-5 h-5 text-emerald-400" />
            Bank & Government Policy Intelligence
          </h3>
          <p className="text-xs text-gray-300 mb-4">Mercury AI continuously analyzes tax credits, R&D grants, and central bank interest policies.</p>
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-gray-200 space-y-2">
            <p className="font-bold text-emerald-300">💡 Q3 Strategic Tax Opportunity</p>
            <p>Your R&D software development expenditure qualifies for a 15% regional tax rebate ($185,000 net savings). Policy verified for software tech platforms.</p>
          </div>
        </Card>
      </div>
    </div>
  );
};
