import React, { useState } from 'react';
import {
  Building2,
  MessageSquare,
  CheckSquare,
  Video,
  PenTool,
  Users,
  Send,
  Plus,
  ExternalLink,
} from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { Input } from '../shared/Input';
import { store } from '../../lib/storage';

export const OfficeRooms: React.FC = () => {
  const rooms = store.getRooms();
  const [selectedRoomId, setSelectedRoomId] = useState(rooms[0].id);
  const [activeTab, setActiveTab] = useState<'chat' | 'tasks' | 'whiteboard' | 'meet'>('chat');
  const [msgText, setMsgText] = useState('');
  const [meetLink, setMeetLink] = useState('');

  const currentRoom = rooms.find((r) => r.id === selectedRoomId) || rooms[0];
  const roomMessages = store.getMessages(selectedRoomId);
  const roomTasks = store.getTasks(selectedRoomId);

  const handleSendMsg = () => {
    if (!msgText.trim()) return;
    store.addMessage(selectedRoomId, msgText);
    setMsgText('');
  };

  const handleGenerateMeet = () => {
    const link = `https://meet.google.com/mercutrix-${currentRoom.slug}-${Math.floor(100 + Math.random() * 900)}`;
    setMeetLink(link);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0D2218] via-[#081811] to-[#040E09] border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <Badge variant="emerald" size="md" className="mb-2">
            COLLABORATIVE OFFICE ROOMS
          </Badge>
          <h1 className="text-3xl font-black text-white">{currentRoom.name}</h1>
          <p className="text-sm text-gray-300 mt-1">
            Dedicated workspace room with real-time chat, shared task boards, whiteboard, and Google Meet integration.
          </p>
        </div>
        <Button onClick={handleGenerateMeet} size="md">
          <Video className="w-4 h-4 text-black" />
          <span>Instant Google Meet</span>
        </Button>
      </div>

      {/* Room Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {rooms.map((r) => (
          <button
            key={r.id}
            onClick={() => setSelectedRoomId(r.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
              selectedRoomId === r.id
                ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
                : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white border border-white/10'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>{r.name}</span>
          </button>
        ))}
      </div>

      {/* Meet Link Display if generated */}
      {meetLink && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-between text-xs text-emerald-300">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-emerald-400" />
            <span className="font-bold">Google Meet Live Room Ready:</span>
            <span className="font-mono underline">{meetLink}</span>
          </div>
          <a
            href={meetLink}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black font-bold flex items-center gap-1 hover:bg-emerald-400"
          >
            <span>Launch Meet</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      )}

      {/* Main Workspace Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Chat/Tasks/Whiteboard View */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/10 pb-2">
            <button
              onClick={() => setActiveTab('chat')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'chat'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-4 h-4" /> Room Chat
            </button>
            <button
              onClick={() => setActiveTab('tasks')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'tasks'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <CheckSquare className="w-4 h-4" /> Shared Tasks
            </button>
            <button
              onClick={() => setActiveTab('whiteboard')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'whiteboard'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <PenTool className="w-4 h-4" /> Whiteboard
            </button>
          </div>

          {activeTab === 'chat' && (
            <Card className="p-6 border-emerald-500/30 flex flex-col h-[420px]">
              <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                {roomMessages.map((m) => (
                  <div key={m.id} className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-emerald-400">{m.userName} ({m.userRole.toUpperCase()})</span>
                      <span className="text-[10px] text-gray-500">{new Date(m.createdAt).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-gray-200">{m.content}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-2">
                <input
                  type="text"
                  value={msgText}
                  onChange={(e) => setMsgText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMsg()}
                  placeholder="Type a message in room chat..."
                  className="flex-1 bg-[#18231C] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                />
                <Button onClick={handleSendMsg} size="sm">
                  <Send className="w-4 h-4 text-black" />
                </Button>
              </div>
            </Card>
          )}

          {activeTab === 'tasks' && (
            <Card className="p-6 border-emerald-500/30">
              <h3 className="font-bold text-base text-white mb-4">Room Task Board</h3>
              <div className="space-y-3">
                {roomTasks.map((t) => (
                  <div key={t.id} className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex justify-between items-center text-xs">
                    <div>
                      <p className="font-bold text-white">{t.title}</p>
                      <span className="text-gray-400">{t.description}</span>
                    </div>
                    <Badge variant={t.priority === 'critical' ? 'rose' : 'emerald'} size="sm">
                      {t.priority}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {activeTab === 'whiteboard' && (
            <Card className="p-6 border-emerald-500/30 text-center flex flex-col items-center justify-center h-[400px] bg-gradient-to-b from-[#111A14] to-[#0A100C]">
              <PenTool className="w-12 h-12 text-emerald-400 mb-3 animate-bounce" />
              <h3 className="font-bold text-lg text-white">Interactive Room Canvas</h3>
              <p className="text-xs text-gray-400 max-w-md mt-1 mb-4">
                Collaborative digital whiteboard powered by Excalidraw integration for architecture diagrams, wireframes, and strategic brainstorming.
              </p>
              <Button size="md">
                <span>Launch Whiteboard Canvas</span>
              </Button>
            </Card>
          )}
        </div>

        {/* Right Col: Room Roster */}
        <Card className="p-6 border-emerald-500/20">
          <h3 className="font-bold text-base text-white mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" />
            Room Roster ({currentRoom.memberCount} Members)
          </h3>
          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-white/5 flex items-center gap-3">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <div>
                <p className="font-bold text-white">Aria Thorne (Founder)</p>
                <span className="text-[10px] text-emerald-400">Online · Room Host</span>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-white/5 flex items-center gap-3">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <div>
                <p className="font-bold text-white">Elena Rostova (CFO)</p>
                <span className="text-[10px] text-emerald-400">Online</span>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-white/5 flex items-center gap-3">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <div>
                <p className="font-bold text-white">David Chen (Senior Eng)</p>
                <span className="text-[10px] text-emerald-400">Online</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};
