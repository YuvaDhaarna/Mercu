import React, { useState } from 'react';
import {
  Users,
  Shield,
  Key,
  UserCheck,
  UserX,
  Plus,
  Lock,
} from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { store } from '../../lib/storage';
import { Role } from '../../types';
import { ROLE_DISPLAY_NAMES, getTier } from '../../lib/permissions';

export const EmployeeManagement: React.FC = () => {
  const profiles = store.getProfiles();
  const [selectedRole, setSelectedRole] = useState<Role>('employee');
  const [inviteLink, setInviteLink] = useState('');

  const handleGenerateInvite = () => {
    const invite = store.generateInvite(selectedRole);
    setInviteLink(`${window.location.origin}/invite?token=${invite.token}`);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0C2218] via-[#081811] to-[#040E09] border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <Badge variant="emerald" size="md" className="mb-2">
            ORGANIZATIONAL PEOPLE & ACCESS CONTROL
          </Badge>
          <h1 className="text-3xl font-black text-white">Employee Roster & Token Generator</h1>
          <p className="text-sm text-gray-300 mt-1">
            Manage company roles, tier assignments, token invitations, and workforce permissions.
          </p>
        </div>
      </div>

      {/* Invite Token Generator Card */}
      <Card className="p-6 border-emerald-500/30 bg-[#121B16]">
        <h3 className="font-bold text-lg text-white mb-3 flex items-center gap-2">
          <Key className="w-5 h-5 text-emerald-400" />
          Generate Secure Invite Token
        </h3>
        <p className="text-xs text-gray-300 mb-4">
          Tokens grant instant access to Mercutrix under the designated role hierarchy and RLS policies.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value as Role)}
            className="w-full sm:w-64 bg-[#18241E] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
          >
            {(['ceo', 'cfo', 'cto', 'coo', 'hr', 'manager', 'team_leader', 'employee'] as Role[]).map((r) => (
              <option key={r} value={r}>
                {ROLE_DISPLAY_NAMES[r]} (Tier {getTier(r)})
              </option>
            ))}
          </select>
          <Button onClick={handleGenerateInvite} size="md">
            <span>Create Token Link</span>
          </Button>
        </div>

        {inviteLink && (
          <div className="mt-4 p-3 rounded-xl bg-black/40 border border-emerald-500/40 text-xs">
            <span className="text-[10px] text-emerald-400 font-bold uppercase block mb-1">Generated Invite Link</span>
            <input
              type="text"
              readOnly
              value={inviteLink}
              className="w-full bg-transparent text-white font-mono focus:outline-none select-all"
            />
          </div>
        )}
      </Card>

      {/* Employee Directory */}
      <Card className="p-6 border-emerald-500/20">
        <h3 className="font-bold text-lg text-white mb-4">Active Team Roster</h3>
        <div className="space-y-3">
          {profiles.map((p) => (
            <div
              key={p.id}
              className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-3">
                <img
                  src={p.avatarUrl}
                  alt={p.fullName}
                  className="w-10 h-10 rounded-xl object-cover border border-emerald-500/40"
                />
                <div>
                  <p className="font-bold text-white text-sm">{p.fullName}</p>
                  <span className="text-gray-400">{p.email}</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="emerald" size="sm">
                  {ROLE_DISPLAY_NAMES[p.role]} (Tier {getTier(p.role)})
                </Badge>
                <span className="text-[10px] font-bold px-2 py-1 rounded bg-emerald-500/20 text-emerald-300">
                  {p.status.toUpperCase()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
