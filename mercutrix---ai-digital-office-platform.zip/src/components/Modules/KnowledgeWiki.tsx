import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  FileText,
  GraduationCap,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';

export const KnowledgeWiki: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const articles = [
    { id: '1', title: 'Mercutrix Digital Office Architecture & RLS Security', cat: 'Engineering', readTime: '5 min' },
    { id: '2', title: 'Q3 Financial Valuation & EBITDA Optimization Guide', cat: 'Finance', readTime: '8 min' },
    { id: '3', title: 'Executive Boardroom & Google Workspace Integration', cat: 'Operations', readTime: '4 min' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0C2218] via-[#081811] to-[#040E09] border border-emerald-500/30">
        <Badge variant="emerald" size="md" className="mb-2">
          CENTRAL KNOWLEDGE BASE & TRAINING
        </Badge>
        <h1 className="text-3xl font-black text-white">Company Wiki & Training Catalog</h1>
        <p className="text-sm text-gray-300 mt-1">
          Universal documentation, SOPs, template library, and AI-assisted onboarding courses.
        </p>
      </div>

      {/* Search Input */}
      <div className="relative max-w-xl">
        <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search documentation, policies, and SOPs..."
          className="w-full bg-[#18241E] border border-white/10 rounded-2xl pl-12 pr-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
        />
      </div>

      {/* Articles List */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {articles.map((a) => (
          <Card key={a.id} className="p-6 border-emerald-500/20 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <Badge variant="emerald" size="sm">{a.cat}</Badge>
                <span className="text-[10px] text-gray-400">{a.readTime}</span>
              </div>
              <h3 className="font-bold text-base text-white">{a.title}</h3>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              <span>Read Documentation</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
};
