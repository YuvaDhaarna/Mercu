import React, { useState } from 'react';
import {
  Workflow,
  Zap,
  CheckCircle,
  Play,
  Plus,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { store } from '../../lib/storage';

export const NoCodeAutomation: React.FC = () => {
  const [ruleName, setRuleName] = useState('');
  const [trigger, setTrigger] = useState('High Stress Score (>7/10)');
  const [action, setAction] = useState('Auto-reschedule meetings & notify manager');

  const workflows = store.getWorkflows();

  const handleCreateRule = () => {
    if (!ruleName.trim()) return;
    store.addWorkflow(ruleName, trigger, action);
    setRuleName('');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0E2218] via-[#091811] to-[#040E09] border border-emerald-500/30">
        <Badge variant="emerald" size="md" className="mb-2">
          MERCURY NO-CODE AUTOMATION ENGINE
        </Badge>
        <h1 className="text-3xl font-black text-white">Automated Workflows & Rules</h1>
        <p className="text-sm text-gray-300 mt-1">
          Construct event-driven workflow automations connecting stress alerts, EBITDA milestones, Google Workspace events, and task delegation.
        </p>
      </div>

      {/* Workflow Builder Box */}
      <Card className="p-6 border-emerald-500/30 bg-[#121B16]">
        <h3 className="font-bold text-lg text-white mb-3 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-400" />
          Construct No-Code Rule
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="text-xs text-gray-300 block mb-1 font-semibold">Rule Name</label>
            <input
              type="text"
              value={ruleName}
              onChange={(e) => setRuleName(e.target.value)}
              placeholder="e.g. Burnout Mitigation Guard"
              className="w-full bg-[#18241E] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
            />
          </div>
          <div>
            <label className="text-xs text-gray-300 block mb-1 font-semibold">Trigger Event</label>
            <select
              value={trigger}
              onChange={(e) => setTrigger(e.target.value)}
              className="w-full bg-[#18241E] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
            >
              <option value="High Stress Score (>7/10)">High Stress Score (&gt;7/10)</option>
              <option value="EBITDA Margin Drops Below 30%">EBITDA Margin Drops Below 30%</option>
              <option value="New Employee Onboarding Token Redeemed">New Employee Onboarding Token Redeemed</option>
              <option value="Overdue Critical Task Count > 3">Overdue Critical Task Count &gt; 3</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-300 block mb-1 font-semibold">Action Executed</label>
            <select
              value={action}
              onChange={(e) => setAction(e.target.value)}
              className="w-full bg-[#18241E] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
            >
              <option value="Auto-reschedule meetings & notify manager">Auto-reschedule meetings &amp; notify manager</option>
              <option value="Send Emergency Alert to Founder & CFO via Gmail">Send Emergency Alert to Founder &amp; CFO via Gmail</option>
              <option value="Create Google Calendar Onboarding Session">Create Google Calendar Onboarding Session</option>
              <option value="Escalate priority & assign Mercury AI helper">Escalate priority &amp; assign Mercury AI helper</option>
            </select>
          </div>
        </div>
        <Button onClick={handleCreateRule} size="md">
          <Zap className="w-4 h-4 text-black" />
          <span>Deploy Workflow Rule</span>
        </Button>
      </Card>

      {/* Active Workflows Grid */}
      <Card className="p-6 border-emerald-500/20">
        <h3 className="font-bold text-lg text-white mb-4">Active System Workflows</h3>
        <div className="space-y-3">
          {workflows.map((w) => (
            <div
              key={w.id}
              className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-sm">{w.name}</span>
                  <Badge variant="emerald" size="sm">ACTIVE</Badge>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <span className="text-emerald-400 font-semibold">IF:</span> {w.trigger}
                  <ArrowRight className="w-3 h-3 text-gray-500" />
                  <span className="text-emerald-400 font-semibold">THEN:</span> {w.action}
                </div>
              </div>
              <Button
                onClick={() => store.toggleWorkflow(w.id)}
                variant={w.active ? 'secondary' : 'outline'}
                size="sm"
              >
                <span>{w.active ? 'Pause Rule' : 'Activate Rule'}</span>
              </Button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
