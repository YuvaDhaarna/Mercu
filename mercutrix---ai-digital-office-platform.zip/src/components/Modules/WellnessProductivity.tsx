import React, { useState } from 'react';
import {
  HeartPulse,
  Flame,
  Timer,
  Moon,
  Footprints,
  Sparkles,
  Coffee,
  CheckCircle2,
  Users,
} from 'lucide-react';
import { StatCard } from '../shared/StatCard';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { store } from '../../lib/storage';

export const WellnessProductivity: React.FC = () => {
  const [breakActive, setBreakActive] = useState(false);
  const health = store.getHealth();

  const overallWellnessScore = 92; // 0-100 AI Score

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0C2218] via-[#081811] to-[#040D09] border border-emerald-500/30">
        <Badge variant="emerald" size="md" className="mb-2">
          AI WELLNESS & PEAK PRODUCTIVITY HUB
        </Badge>
        <h1 className="text-3xl font-black text-white">Wellness & Focus Analytics</h1>
        <p className="text-sm text-gray-300 mt-1">
          Monitor step counts, sleep duration, stress levels, deep work ratio, and receive personalized AI health recommendations.
        </p>
      </div>

      {/* Wellness Score Card */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-6 border-emerald-500/40 bg-gradient-to-br from-[#14261C] to-[#0B150F] text-center md:col-span-1">
          <HeartPulse className="w-10 h-10 text-emerald-400 mx-auto mb-2 animate-pulse" />
          <span className="text-xs font-semibold uppercase text-gray-400">AI Wellness Score</span>
          <div className="text-4xl font-black text-emerald-400 my-2">{overallWellnessScore}/100</div>
          <Badge variant="emerald" size="sm">
            OPTIMAL FLOW STATE
          </Badge>
        </Card>

        <div className="md:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatCard title="Step Count" value={health.steps.toLocaleString()} subtitle="Goal: 10,000" icon={<Footprints className="w-5 h-5" />} />
          <StatCard title="Sleep Quality" value={`${health.sleepHours} hrs`} subtitle="7.8 hrs Restful" icon={<Moon className="w-5 h-5" />} />
          <StatCard title="Stress Level" value={`${health.stressLevel}/10`} badge="LOW STRESS" icon={<Flame className="w-5 h-5" />} />
        </div>
      </div>

      {/* Break & AI Health Advice */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6 border-emerald-500/30">
          <h3 className="font-bold text-lg text-white mb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            Mercury Personalized AI Health Recommendations
          </h3>
          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-gray-200 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-emerald-300">🚶 Afternoon Walk Recommendation</p>
                <p className="mt-1">Your screen time reached 210 minutes. A 15-minute outdoor walk at 3:30 PM will reduce cognitive fatigue and boost Q3 creative output by 28%.</p>
              </div>
            </div>
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-gray-200 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-emerald-300">🎯 Deep Work Focus Ratio</p>
                <p className="mt-1">You completed 180 minutes of deep focus work today. Keep interruptions under 2 sessions for maximum productivity.</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Restorative Break Trigger */}
        <Card className="p-6 border-emerald-500/30 bg-gradient-to-b from-[#132219] to-[#0A120E]">
          <Coffee className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
          <h3 className="font-bold text-base text-white text-center">Take Restorative Break</h3>
          <p className="text-xs text-gray-300 text-center my-3">
            Logging regular 5-minute breaks automatically notifies your manager and logs work wellness points.
          </p>
          <Button
            onClick={() => setBreakActive(!breakActive)}
            className="w-full h-11"
          >
            <span>{breakActive ? 'End Break' : 'Start 5-Min Break'}</span>
          </Button>
        </Card>
      </div>
    </div>
  );
};
