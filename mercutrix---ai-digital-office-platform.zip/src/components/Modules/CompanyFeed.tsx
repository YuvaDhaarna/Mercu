import React, { useState } from 'react';
import {
  Share2,
  Heart,
  MessageCircle,
  Megaphone,
  Award,
  Send,
  Sparkles,
} from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Badge } from '../shared/Badge';
import { store } from '../../lib/storage';

export const CompanyFeed: React.FC = () => {
  const [postText, setMsgText] = useState('');
  const [postType, setPostType] = useState<'post' | 'announcement' | 'achievement'>('post');
  const [commentInput, setCommentInput] = useState<Record<string, string>>({});

  const feed = store.getFeed();

  const handleCreatePost = () => {
    if (!postText.trim()) return;
    store.addFeedPost(postText, postType);
    setMsgText('');
  };

  const handleAddComment = (postId: string) => {
    const txt = commentInput[postId];
    if (!txt || !txt.trim()) return;
    store.addComment(postId, txt);
    setCommentInput((prev) => ({ ...prev, [postId]: '' }));
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      {/* Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0D2218] via-[#081811] to-[#040E09] border border-emerald-500/30">
        <Badge variant="emerald" size="md" className="mb-2">
          ORGANIZATIONAL TOWN HALL & FEED
        </Badge>
        <h1 className="text-3xl font-black text-white">Company Feed & Announcements</h1>
        <p className="text-sm text-gray-300 mt-1">
          Share executive updates, team achievements, milestones, and connect across departments.
        </p>
      </div>

      {/* Post Creator Box */}
      <Card className="p-6 border-emerald-500/30 bg-[#121A15]">
        <div className="flex items-center gap-3 mb-3">
          <Sparkles className="w-5 h-5 text-emerald-400" />
          <span className="font-bold text-sm text-white">Create Announcement or Post</span>
        </div>
        <textarea
          rows={3}
          value={postText}
          onChange={(e) => setMsgText(e.target.value)}
          placeholder="Share an executive update, achievement, or team milestone..."
          className="w-full bg-[#18241E] border border-white/10 rounded-xl p-3.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 mb-3"
        />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPostType('post')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                postType === 'post' ? 'bg-emerald-500 text-black font-bold' : 'bg-white/5 text-gray-400'
              }`}
            >
              Update
            </button>
            <button
              onClick={() => setPostType('announcement')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                postType === 'announcement' ? 'bg-emerald-500 text-black font-bold' : 'bg-white/5 text-gray-400'
              }`}
            >
              Announcement
            </button>
            <button
              onClick={() => setPostType('achievement')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                postType === 'achievement' ? 'bg-emerald-500 text-black font-bold' : 'bg-white/5 text-gray-400'
              }`}
            >
              Achievement
            </button>
          </div>
          <Button onClick={handleCreatePost} size="sm">
            <Send className="w-4 h-4 text-black" />
            <span>Publish Post</span>
          </Button>
        </div>
      </Card>

      {/* Posts Stream */}
      <div className="space-y-4">
        {feed.map((p) => (
          <Card key={p.id} className="p-6 border-emerald-500/20">
            {/* Author */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <img
                  src={p.authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250'}
                  alt={p.authorName}
                  className="w-10 h-10 rounded-xl object-cover border border-emerald-500/40"
                />
                <div>
                  <h4 className="font-bold text-sm text-white">{p.authorName}</h4>
                  <span className="text-[10px] text-emerald-400 font-semibold">{p.authorRole.toUpperCase()}</span>
                </div>
              </div>
              <Badge variant={p.type === 'announcement' ? 'amber' : p.type === 'achievement' ? 'purple' : 'emerald'} size="sm">
                {p.type.toUpperCase()}
              </Badge>
            </div>

            {/* Content */}
            <p className="text-xs text-gray-200 leading-relaxed mb-4 whitespace-pre-wrap">{p.content}</p>

            {/* Actions */}
            <div className="flex items-center gap-4 border-t border-white/10 pt-3 text-xs text-gray-400">
              <button
                onClick={() => store.toggleLikePost(p.id)}
                className={`flex items-center gap-1.5 font-bold transition-colors ${
                  p.likedByMe ? 'text-rose-400' : 'hover:text-white'
                }`}
              >
                <Heart className={`w-4 h-4 ${p.likedByMe ? 'fill-rose-400' : ''}`} />
                <span>{p.likes} Likes</span>
              </button>
              <div className="flex items-center gap-1.5 font-bold">
                <MessageCircle className="w-4 h-4" />
                <span>{p.comments.length} Comments</span>
              </div>
            </div>

            {/* Comments List */}
            {p.comments.length > 0 && (
              <div className="mt-3 pt-3 space-y-2 border-t border-white/5">
                {p.comments.map((c) => (
                  <div key={c.id} className="p-2.5 rounded-xl bg-white/5 text-xs">
                    <span className="font-bold text-emerald-400">{c.authorName}: </span>
                    <span className="text-gray-300">{c.content}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Add Comment Input */}
            <div className="mt-3 flex items-center gap-2">
              <input
                type="text"
                value={commentInput[p.id] || ''}
                onChange={(e) => setCommentInput({ ...commentInput, [p.id]: e.target.value })}
                onKeyDown={(e) => e.key === 'Enter' && handleAddComment(p.id)}
                placeholder="Write a comment..."
                className="flex-1 bg-[#18231C] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
              />
              <Button onClick={() => handleAddComment(p.id)} size="sm">
                Comment
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
