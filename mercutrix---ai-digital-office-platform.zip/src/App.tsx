import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { TopBar } from './components/layout/TopBar';
import { MercuryAIPanel } from './components/MercuryAI/MercuryAIPanel';
import { FounderDashboard } from './components/Dashboard/FounderDashboard';
import { ExecutiveDashboard } from './components/Dashboard/ExecutiveDashboard';
import { ManagerDashboard } from './components/Dashboard/ManagerDashboard';
import { EmployeeDashboard } from './components/Dashboard/EmployeeDashboard';
import { FinancialIntelligence } from './components/Modules/FinancialIntelligence';
import { WellnessProductivity } from './components/Modules/WellnessProductivity';
import { OfficeRooms } from './components/Modules/OfficeRooms';
import { GoogleWorkspaceHub } from './components/Modules/GoogleWorkspaceHub';
import { CompanyFeed } from './components/Modules/CompanyFeed';
import { NoCodeAutomation } from './components/Modules/NoCodeAutomation';
import { EmployeeManagement } from './components/Modules/EmployeeManagement';
import { KnowledgeWiki } from './components/Modules/KnowledgeWiki';
import { DatabaseSchemaViewer } from './components/Modules/DatabaseSchemaViewer';
import { store } from './lib/storage';
import { Profile, Role } from './types';

export function App() {
  const [currentUser, setCurrentUser] = useState<Profile>(store.getCurrentUser());
  const [activeTab, setActiveTab] = useState<string>('founder-room');
  const [isMercuryOpen, setIsMercuryOpen] = useState(false);

  useEffect(() => {
    const handleStorageChange = () => {
      setCurrentUser(store.getCurrentUser());
    };
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('mercutrix-role-change', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('mercutrix-role-change', handleStorageChange);
    };
  }, []);

  const handleTabChange = (tab: string) => {
    if (tab === 'mercury-ai') {
      setIsMercuryOpen(true);
      return;
    }
    setActiveTab(tab);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'founder-room':
        return <FounderDashboard onNavigate={handleTabChange} />;
      case 'executive-suite':
        return <ExecutiveDashboard onNavigate={handleTabChange} />;
      case 'financial-intelligence':
        return <FinancialIntelligence />;
      case 'manager-hub':
        return <ManagerDashboard onNavigate={handleTabChange} />;
      case 'employee-workspace':
        return <EmployeeDashboard onNavigate={handleTabChange} />;
      case 'office-rooms':
        return <OfficeRooms />;
      case 'wellness-productivity':
        return <WellnessProductivity />;
      case 'company-feed':
        return <CompanyFeed />;
      case 'google-workspace':
        return <GoogleWorkspaceHub />;
      case 'no-code-automation':
        return <NoCodeAutomation />;
      case 'employee-management':
        return <EmployeeManagement />;
      case 'knowledge-wiki':
        return <KnowledgeWiki />;
      case 'database-schema':
        return <DatabaseSchemaViewer />;
      default:
        return <FounderDashboard onNavigate={handleTabChange} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-slate-100 font-sans selection:bg-emerald-500 selection:text-black flex overflow-x-hidden bg-[radial-gradient(circle_at_top_right,#065F4611,transparent_40%)]">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        role={currentUser.role}
      />

      {/* Main App Layout */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <TopBar
          currentUser={currentUser}
          onOpenMercuryAI={() => setIsMercuryOpen(true)}
          onSearch={(query) => console.log('Search query:', query)}
        />

        <main className="flex-1 p-6 md:p-8 max-w-[1600px] w-full mx-auto">
          {renderTabContent()}
        </main>
      </div>

      {/* Floating/Slide-over Mercury AI Assistant Panel */}
      <MercuryAIPanel
        isOpen={isMercuryOpen}
        onClose={() => setIsMercuryOpen(false)}
        currentRole={currentUser.role}
      />
    </div>
  );
}

export default App;
